// apps.go
//go:build !android && !ios

package apps

import (
	"encoding/json"
	"fmt"
	"io/fs"
	"log/slog"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/getlantern/lantern/lantern-core/internal/processpath"
)

const cacheFilename = "apps_cache.json"

type Callback func(...*AppData) error

func loadCacheFromFile(dataDir string) ([]*AppData, error) {
	path := filepath.Join(dataDir, cacheFilename)
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var cached []*AppData
	if err := json.Unmarshal(data, &cached); err != nil {
		return nil, err
	}
	normalizeAppPaths(cached...)

	return cached, nil
}

func normalizeAppPaths(apps ...*AppData) {
	for _, app := range apps {
		if app == nil {
			continue
		}
		path := processpath.Normalize(app.AppPath)
		if app.BundleID == app.AppPath {
			app.BundleID = path
		}
		app.AppPath = path
	}
}

func saveCacheToFile(dataDir string, apps ...*AppData) error {
	if err := os.MkdirAll(dataDir, 0o755); err != nil {
		return fmt.Errorf("creating data dir: %w", err)
	}
	path := filepath.Join(dataDir, cacheFilename)

	// Keep the apps catalog lightweight. Row-level icon bytes are fetched lazily
	// and cached separately, so we don't need large inline blobs in this file.
	stripped := make([]*AppData, 0, len(apps))
	for _, a := range apps {
		if a == nil {
			continue
		}
		cp := *a
		cp.IconBytes = nil
		stripped = append(stripped, &cp)
	}

	b, err := json.Marshal(stripped)
	if err != nil {
		return fmt.Errorf("marshal cache: %w", err)
	}

	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return fmt.Errorf("write tmp cache: %w", err)
	}
	if err := os.Rename(tmp, path); err != nil {
		return fmt.Errorf("rename cache: %w", err)
	}

	slog.Debug("Saved apps cache", "path", path, "count", len(stripped))
	return nil
}

func normalizeKey(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return ""
	}
	if runtime.GOOS == "windows" {
		s = strings.ToLower(s)
	}
	return s
}

// scanAppDirs walks the provided app directories and emits AppData for any *.app bundles
func scanAppDirs(appDirs []string, seen map[string]bool, excludeDirs []string, cb Callback) []*AppData {
	var apps []*AppData

	for _, dir := range appDirs {
		dir = strings.TrimSpace(dir)
		if dir == "" {
			continue
		}

		info, err := os.Stat(dir)
		if err != nil || !info.IsDir() {
			continue
		}

		_ = filepath.WalkDir(dir, func(path string, d fs.DirEntry, err error) error {
			if err != nil || d == nil {
				slog.Debug("walk error", "path", path, "error", err)
				return nil
			}

			for _, ex := range excludeDirs {
				if ex == "" {
					continue
				}
				p := path
				e := ex
				if runtime.GOOS == "windows" {
					p = strings.ToLower(p)
					e = strings.ToLower(e)
				}
				if strings.HasPrefix(p, e) {
					return filepath.SkipDir
				}
			}

			base := filepath.Base(path)
			if !strings.HasSuffix(strings.ToLower(base), strings.ToLower(appExtension)) {
				return nil
			}

			// A linked bundle runs from its target, which is the path rules
			// have to match. /Applications/Safari.app is one.
			isDir := d.IsDir()
			if appIsDir && d.Type()&fs.ModeSymlink != 0 {
				// A broken link is skipped.
				target, _ := filepath.EvalSymlinks(path)
				info, _ := os.Stat(target)
				if info == nil {
					return nil
				}
				path, isDir = target, info.IsDir()
			}
			if isDir && !appIsDir || !isDir && appIsDir {
				return nil
			}
			// SkipDir on a link would skip the rest of its parent directory.
			var skipBundle error
			if d.IsDir() {
				skipBundle = filepath.SkipDir
			}

			appID, err := getAppID(path)
			if err != nil {
				return nil
			}

			rawName := strings.TrimSuffix(base, appExtension)
			if isExcludedName(rawName) {
				return nil
			}
			if runtime.GOOS == "windows" && isWindowsSystemApp(path, rawName) {
				return nil
			}
			if runtime.GOOS == "windows" && isWindowsUtilityApp(path, rawName) {
				return nil
			}
			if shouldExcludeAppBundle(path, rawName, appID) {
				return skipBundle
			}

			keyID := normalizeKey(appID)
			keyPath := normalizeKey(path)
			keyName := normalizeKey(rawName)

			if seen[keyID] || seen[keyPath] || (runtime.GOOS != "windows" && seen[keyName]) {
				// Don't descend into a bundle we already know about, or its
				// embedded helper apps (Xcode's agents, inspectors, ...) get
				// listed as if they were installed apps.
				return skipBundle
			}

			iconPath, _ := getIconPath(path)

			var iconBytes []byte
			if runtime.GOOS != "windows" {
				if b, err := getIconBytes(path); err == nil {
					iconBytes = b
				}
			}

			app := &AppData{
				BundleID:  appID,
				Name:      humanizeName(rawName),
				AppPath:   path,
				IconPath:  iconPath,
				IconBytes: iconBytes,

				WrappedBundle: wrappedBundleName(path),
			}

			if cb != nil {
				if err := cb(app); err != nil {
					slog.Debug("apps callback returned error", "app", app.Name, "error", err)
				}
			}

			apps = append(apps, app)

			seen[keyID] = true
			seen[keyPath] = true
			if runtime.GOOS != "windows" {
				seen[keyName] = true
			}

			return skipBundle
		})
	}

	return apps
}

func isExcludedName(name string) bool {
	n := strings.ToLower(strings.TrimSpace(name))
	n = strings.TrimSuffix(n, strings.ToLower(appExtension))
	n = strings.Trim(n, ".-_ ")
	return excludeNames[n]
}

func humanizeName(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return ""
	}
	r, size := utf8.DecodeRuneInString(s)
	if r == utf8.RuneError {
		return s
	}
	return string(unicode.ToUpper(r)) + s[size:]
}

// LoadInstalledApps scans for installed apps (and may return cached results first)
func LoadInstalledApps(dataDir string, cb Callback) {
	dirs := defaultAppDirs()
	LoadInstalledAppsWithDirs(dataDir, dirs, excludeDirs, cb)
}

// LoadInstalledAppsWithDirs scans appDirs, emitting cached items first (if present),
// then newly discovered ones. It returns the count of newly discovered apps
func LoadInstalledAppsWithDirs(dataDir string, appDirs []string, excludeDirs []string, cb Callback) (int, error) {
	seen := make(map[string]bool)
	var deferredWindowsCache []*AppData

	if cached, err := loadCacheFromFile(dataDir); err == nil {
		// Recompute rather than trust flags persisted by an older cache.
		markBrowsers(cached)
		for _, app := range cached {
			if app == nil {
				continue
			}
			if runtime.GOOS == "windows" && isWindowsSystemApp(app.AppPath, app.Name) {
				continue
			}
			if runtime.GOOS == "windows" && isWindowsUtilityApp(app.AppPath, app.Name) {
				continue
			}
			if runtime.GOOS == "windows" &&
				len(app.IconBytes) == 0 &&
				strings.TrimSpace(app.IconPath) == "" {
				// Re-add only if scan doesn't rediscover them with richer metadata.
				deferredWindowsCache = append(deferredWindowsCache, app)
				continue
			}
			if cb != nil {
				cb(app)
			}
			if runtime.GOOS == "windows" {
				// Keep cached entries as an initial snapshot only.
				// We still want a full live rescan to refresh stale metadata/icons.
				continue
			}
			if app.BundleID != "" {
				seen[normalizeKey(app.BundleID)] = true
			}
			if app.AppPath != "" {
				seen[normalizeKey(app.AppPath)] = true
			}
			if app.Name != "" {
				// on non-windows scanAppDirs also dedups by name
				seen[normalizeKey(app.Name)] = true
			}
		}
	}

	found := loadInstalledAppsPlatform(appDirs, seen, excludeDirs, func(apps ...*AppData) error {
		normalizeAppPaths(apps...)
		if cb != nil {
			return cb(apps...)
		}
		return nil
	})
	// The callback has already streamed these pointers to the caller
	// (LanternCore.LoadInstalledApps collects them and marshals after we
	// return), so mutating them here is visible in the final JSON and in
	// the cache saved below.
	markBrowsers(found)
	if runtime.GOOS == "windows" {
		for _, app := range deferredWindowsCache {
			if app == nil {
				continue
			}
			if strings.TrimSpace(app.AppPath) == "" {
				continue
			}
			if _, err := os.Stat(app.AppPath); err != nil {
				continue
			}
			if isWindowsSystemApp(app.AppPath, app.Name) {
				continue
			}
			if isWindowsUtilityApp(app.AppPath, app.Name) {
				continue
			}

			keyID := normalizeKey(app.BundleID)
			keyPath := normalizeKey(app.AppPath)
			keyName := normalizeKey(app.Name)
			if (keyID != "" && seen[keyID]) ||
				(keyPath != "" && seen[keyPath]) ||
				(keyName != "" && seen[keyName]) {
				continue
			}

			if cb != nil {
				cb(app)
			}
			found = append(found, app)

			if keyID != "" {
				seen[keyID] = true
			}
			if keyPath != "" {
				seen[keyPath] = true
			}
			if keyName != "" {
				seen[keyName] = true
			}
		}
	}

	if err := saveCacheToFile(dataDir, found...); err != nil {
		slog.Error("unable to save apps cache", "error", err)
		return len(found), err
	}
	return len(found), nil
}
