//go:build !android && !ios

package apps

import (
	"bytes"
	"image"
	"image/png"
	"math/rand"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"

	"github.com/alecthomas/assert/v2"
)

// pngBytes encodes a square PNG of the given side. A noisy image compresses
// poorly, so a small noisy icon can be more bytes than a large flat one.
func pngBytes(t *testing.T, side int, noisy bool) string {
	t.Helper()
	img := image.NewNRGBA(image.Rect(0, 0, side, side))
	rng := rand.New(rand.NewSource(int64(side)))
	for i := range img.Pix {
		if noisy {
			img.Pix[i] = byte(rng.Intn(256))
		} else {
			img.Pix[i] = 0xff
		}
	}
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		t.Fatal(err)
	}
	return buf.String()
}

func writeFile(t *testing.T, path, content string, mode os.FileMode) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("mkdir %s: %v", path, err)
	}
	if err := os.WriteFile(path, []byte(content), mode); err != nil {
		t.Fatalf("write %s: %v", path, err)
	}
}

func makeAppBundle(t *testing.T, root, name, bundleID string, withIcon bool) string {
	t.Helper()
	app := filepath.Join(root, name+".app")
	infoPlist := `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleIdentifier</key>
	<string>` + bundleID + `</string>
</dict>
</plist>`
	writeFile(t, filepath.Join(app, "Contents", "Info.plist"), infoPlist, 0o644)
	if withIcon {
		writeFile(t, filepath.Join(app, "Contents", "Resources", "AppIcon.icns"), "notreal", 0o644)
	}
	return app
}

func TestScanAppDirs_FindsAppsAndIconWindows(t *testing.T) {
	t.Skipf("Skipping Windows-specific test on %s", runtime.GOOS)
	tmp := t.TempDir()
	root := filepath.Join(tmp, "Program Files")
	//root := "C:\\Program Files"
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	//appPath := makeExe(t, root)

	appPath := ""
	cb := func(a ...*AppData) error {
		return nil
	}

	apps := scanAppDirs(defaultAppDirs(), map[string]bool{}, excludeDirs, cb)
	if len(apps) != 1 {
		t.Fatalf("expected 1 app, got %d", len(apps))
	}
	if runtime.GOOS == "darwin" {
		if apps[0].BundleID != "org.getlantern.lantern" {
			t.Fatalf("app ID mismatch: %s", apps[0].BundleID)
		}
	} else if runtime.GOOS == "windows" {
		assert.Equal(t, apps[0].BundleID, appPath, "app ID should match app path on Windows")
	}
	if apps[0].AppPath != appPath {
		t.Fatalf("app path mismatch: %s", apps[0].AppPath)
	}
	if apps[0].Name != "Notepad" {
		t.Fatalf("app name mismatch: %s", apps[0].Name)
	}
}

func TestScanAppDirs_FindsAppsAndIcon(t *testing.T) {
	if runtime.GOOS != "darwin" {
		t.Skip("test requires macOS .app bundle scanning")
	}
	tmp := t.TempDir()
	root := filepath.Join(tmp, "Applications")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	appPath := makeAppBundle(t, root, "Lantern", "org.getlantern.lantern", true)

	var got []*AppData
	cb := func(a ...*AppData) error {
		got = append(got, a...)
		return nil
	}

	apps := scanAppDirs([]string{root}, map[string]bool{}, excludeDirs, cb)
	if len(apps) != 1 {
		t.Fatalf("expected 1 app, got %d", len(apps))
	}
	if apps[0].BundleID != "org.getlantern.lantern" {
		t.Fatalf("bundle ID mismatch: %s", apps[0].BundleID)
	}
	if apps[0].AppPath != appPath {
		t.Fatalf("app path mismatch: %s", apps[0].AppPath)
	}
	if apps[0].Name != "Lantern" {
		t.Fatalf("app name mismatch: %s", apps[0].Name)
	}
	if !strings.HasSuffix(apps[0].IconPath, ".icns") {
		t.Fatalf("expected an .icns icon, got %q", apps[0].IconPath)
	}
	// Callback received the same item
	if len(got) != 1 || got[0].BundleID != "org.getlantern.lantern" {
		t.Fatalf("callback did not receive app data")
	}
}

func TestScanAppDirs_DedupByBundleID(t *testing.T) {
	if runtime.GOOS != "darwin" {
		t.Skip("test requires macOS .app bundle scanning")
	}
	tmp := t.TempDir()
	root := filepath.Join(tmp, "Applications")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	makeAppBundle(t, root, "A", "com.example.same", false)
	// Same bundle ID, different name/path
	makeAppBundle(t, root, "B", "com.example.same", false)

	var got []*AppData
	cb := func(a ...*AppData) error { got = append(got, a...); return nil }

	apps := scanAppDirs([]string{root}, map[string]bool{}, excludeDirs, cb)
	if len(apps) != 1 {
		t.Fatalf("expected 1 app due to de-dup, got %d", len(apps))
	}
	if apps[0].BundleID != "com.example.same" {
		t.Fatalf("unexpected bundle id: %s", apps[0].BundleID)
	}
}

func TestCacheLoadSaveRoundTrip(t *testing.T) {
	tmp := t.TempDir()
	a1 := &AppData{Name: "One", BundleID: "com.x.one", AppPath: "/X/One.app"}
	a2 := &AppData{Name: "Two", BundleID: "com.x.two", AppPath: "/X/Two.app"}

	if err := saveCacheToFile(tmp, a1, a2); err != nil {
		t.Fatalf("save cache: %v", err)
	}
	got, err := loadCacheFromFile(tmp)
	if err != nil {
		t.Fatalf("load cache: %v", err)
	}
	if len(got) != 2 {
		t.Fatalf("want 2, got %d", len(got))
	}
}

func TestLoadInstalledAppsWithDirs_EmitsCachedThenNew(t *testing.T) {
	if runtime.GOOS != "darwin" {
		t.Skip("test requires macOS .app bundle scanning")
	}
	tmp := t.TempDir()

	cached := &AppData{Name: "Cached", BundleID: "com.cached", AppPath: "/Cached.app"}
	if err := saveCacheToFile(tmp, cached); err != nil {
		t.Fatalf("seed cache: %v", err)
	}

	root := filepath.Join(tmp, "ScanRoot")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	makeAppBundle(t, root, "Fresh", "com.fresh", false)

	var seen []string
	cb := func(a ...*AppData) error {
		for _, x := range a {
			seen = append(seen, x.BundleID)
		}
		return nil
	}

	n, err := LoadInstalledAppsWithDirs(tmp, []string{root}, excludeDirs, cb)
	if err != nil {
		t.Fatalf("got error: %v", err)
	}
	if n != 1 {
		t.Fatalf("expected 1 new app, got %d", n)
	}
	hasCached, hasFresh := false, false
	for _, b := range seen {
		if b == "com.cached" {
			hasCached = true
		}
		if b == "com.fresh" {
			hasFresh = true
		}
	}
	if !hasCached || !hasFresh {
		t.Fatalf("callback did not receive both cached and fresh apps; got %v", seen)
	}
}

// makeWrappedAppBundle mimics an iPhone/iPad app installed from the Mac App
// Store: no Contents/, the real bundle under Wrapper/ with a different name,
// Info.plist at its root and PNG icons instead of .icns.
func makeWrappedAppBundle(t *testing.T, root, name, inner, bundleID string) string {
	t.Helper()
	app := filepath.Join(root, name+".app")
	innerApp := filepath.Join(app, "Wrapper", inner+".app")
	infoPlist := `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleIdentifier</key>
	<string>` + bundleID + `</string>
</dict>
</plist>`
	writeFile(t, filepath.Join(innerApp, "Info.plist"), infoPlist, 0o644)
	writeFile(t, filepath.Join(innerApp, "AppIcon29x29.png"), pngBytes(t, 29, false), 0o644)
	writeFile(t, filepath.Join(innerApp, "AppIcon60x60@3x.png"), pngBytes(t, 180, false), 0o644)
	if err := os.Symlink(filepath.Join("Wrapper", inner+".app"), filepath.Join(app, "WrappedBundle")); err != nil {
		t.Fatal(err)
	}
	return app
}

func TestScanAppDirs_FindsWrappedIOSApp(t *testing.T) {
	if runtime.GOOS != "darwin" {
		t.Skip("test requires macOS .app bundle scanning")
	}
	tmp := t.TempDir()
	root := filepath.Join(tmp, "Applications")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	appPath := makeWrappedAppBundle(t, root, "Stream", "NetworkSniffer", "com.fish.stream")
	nativePath := makeAppBundle(t, root, "Native", "com.example.native", false)
	// Brackets are glob metacharacters; the bundle must still be found.
	makeWrappedAppBundle(t, root, "Stream [Beta]", "NetworkSnifferBeta", "com.fish.stream.beta")

	apps := scanAppDirs([]string{root}, map[string]bool{}, excludeDirs, nil)
	if len(apps) != 3 {
		t.Fatalf("expected 3 apps (outer wrappers only, inner bundles must not be listed separately), got %d: %+v", len(apps), apps)
	}
	byID := map[string]*AppData{}
	for _, a := range apps {
		byID[a.BundleID] = a
	}

	wrapped := byID["com.fish.stream"]
	if wrapped == nil {
		t.Fatalf("wrapped app missing: %+v", apps)
	}
	if wrapped.AppPath != appPath {
		t.Errorf("app path: got %s want %s", wrapped.AppPath, appPath)
	}
	if wrapped.Name != "Stream" {
		t.Errorf("name should come from the outer bundle: %s", wrapped.Name)
	}
	if wrapped.WrappedBundle != "NetworkSniffer.app" {
		t.Errorf("wrappedBundle: got %q want NetworkSniffer.app", wrapped.WrappedBundle)
	}
	if filepath.Base(wrapped.IconPath) != "AppIcon60x60@3x.png" {
		t.Errorf("icon should be the largest PNG: %s", wrapped.IconPath)
	}

	if beta := byID["com.fish.stream.beta"]; beta == nil || beta.WrappedBundle != "NetworkSnifferBeta.app" {
		t.Errorf("bracketed wrapped app missing or wrong inner bundle: %+v", beta)
	}

	native := byID["com.example.native"]
	if native == nil || native.AppPath != nativePath {
		t.Fatalf("native app missing or wrong path: %+v", native)
	}
	if native.WrappedBundle != "" {
		t.Errorf("native app must not report a wrapped bundle: %q", native.WrappedBundle)
	}
}

func TestScanAppDirs_SeenBundleIsNotDescendedInto(t *testing.T) {
	if runtime.GOOS != "darwin" {
		t.Skip("test requires macOS .app bundle scanning")
	}
	root := filepath.Join(t.TempDir(), "Applications")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	outer := makeAppBundle(t, root, "Xcode", "com.apple.dt.Xcode", false)
	// Helper app embedded in the outer bundle, as Xcode ships.
	makeAppBundle(t, filepath.Join(outer, "Contents", "Applications"), "Instruments", "com.apple.dt.Instruments", false)

	// Outer bundle already known from the cache.
	seen := map[string]bool{normalizeKey(outer): true}
	apps := scanAppDirs([]string{root}, seen, excludeDirs, nil)
	if len(apps) != 0 {
		t.Fatalf("expected no apps (outer already seen, helper must not surface), got %+v", apps)
	}
}

func TestScanAppDirs_FollowsLinkedBundle(t *testing.T) {
	if runtime.GOOS != "darwin" {
		t.Skip("test requires macOS .app bundle scanning")
	}
	tmp := t.TempDir()
	root := filepath.Join(tmp, "Applications")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	// Safari's layout: the bundle lives elsewhere and /Applications links to it.
	target := makeAppBundle(t, filepath.Join(tmp, "Cryptex"), "Safari", "com.apple.Safari", false)
	if err := os.Symlink(target, filepath.Join(root, "Safari.app")); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(filepath.Join(tmp, "missing.app"), filepath.Join(root, "Broken.app")); err != nil {
		t.Fatal(err)
	}
	// Sorts after the links, so it is missed if a link stops the walk.
	makeAppBundle(t, root, "Zed", "dev.zed.Zed", false)

	apps := scanAppDirs([]string{root}, map[string]bool{}, excludeDirs, nil)
	if len(apps) != 2 {
		t.Fatalf("expected Safari and Zed, got %+v", apps)
	}
	byID := map[string]*AppData{}
	for _, a := range apps {
		byID[a.BundleID] = a
	}
	safari := byID["com.apple.Safari"]
	if safari == nil {
		t.Fatalf("linked bundle missing: %+v", apps)
	}
	// Processes report the resolved path, so that is what a rule needs.
	want, err := filepath.EvalSymlinks(target)
	if err != nil {
		t.Fatal(err)
	}
	if safari.AppPath != want {
		t.Errorf("app path: got %s want %s", safari.AppPath, want)
	}
	if byID["dev.zed.Zed"] == nil {
		t.Errorf("bundle after the link missing: %+v", apps)
	}
}
