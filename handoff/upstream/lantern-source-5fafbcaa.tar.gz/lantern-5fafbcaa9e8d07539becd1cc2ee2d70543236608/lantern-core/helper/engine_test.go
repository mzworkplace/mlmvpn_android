package helper

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"golang.org/x/crypto/chacha20poly1305"

	"github.com/getlantern/broflake/common/helperinvite"
)

var testKey = base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{1}, 32))

func newTestEngine(t *testing.T, cloud *fakeCloud, device, dir string) *Engine {
	t.Helper()
	e := NewEngine(dir, cloud.relay(device), nil)
	call(t, e, "unlock", map[string]any{"key": testKey})
	return e
}

func call(t *testing.T, e *Engine, op string, args map[string]any) map[string]any {
	t.Helper()
	out, err := e.Call(context.Background(), op, mustJSON(args))
	require.NoError(t, err, op)
	var m map[string]any
	require.NoError(t, json.Unmarshal(out, &m))
	return m
}

func callErr(t *testing.T, e *Engine, op string, args map[string]any) string {
	t.Helper()
	_, err := e.Call(context.Background(), op, mustJSON(args))
	var he *Error
	require.True(t, errors.As(err, &he), "%s: want *Error, got %v", op, err)
	return he.Code
}

func list(m map[string]any, key string) []map[string]any {
	raw, _ := m[key].([]any)
	out := make([]map[string]any, 0, len(raw))
	for _, r := range raw {
		out = append(out, r.(map[string]any))
	}
	return out
}

func TestInviteClaimApproveEnd(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara-device", t.TempDir())
	aliDir := t.TempDir()
	ali := newTestEngine(t, cloud, "ali-device", aliDir)

	inv := call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	link := inv["link"].(string)
	require.True(t, strings.HasPrefix(link, helperinvite.LinkPrefix))
	pending := list(call(t, sara, "view", nil), "invites")
	require.Len(t, pending, 1)
	assert.Equal(t, "pending", pending[0]["state"])
	assert.Equal(t, link, pending[0]["link"], "an unclaimed invite can be re-shared")

	cl := call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	code := cl["code"].(string)
	assert.Regexp(t, `^[0-9]{4}$`, code)
	assert.Len(t, list(call(t, ali, "view", nil), "claims"), 1)

	sv := call(t, sara, "refresh", nil)
	claimed := list(sv, "invites")
	require.Len(t, claimed, 1)
	assert.Equal(t, "claimed", claimed[0]["state"])
	assert.Equal(t, code, claimed[0]["code"], "both sides compute the same code")
	assert.Equal(t, "Ali", claimed[0]["volunteer_name"])
	assert.Nil(t, claimed[0]["link"], "a claimed invite no longer offers its link")

	sv = call(t, sara, "decide", map[string]any{"invite_id": claimed[0]["id"], "approve": true})
	assert.Empty(t, list(sv, "invites"), "a decided invite is forgotten, with its secret")
	helpers := list(sv, "helpers")
	require.Len(t, helpers, 1)
	assert.Equal(t, "Ali", helpers[0]["name"])
	assert.Nil(t, helpers[0]["online"])

	cloud.online["ali-device"] = true
	helpers = list(call(t, sara, "refresh", nil), "helpers")
	assert.Equal(t, true, helpers[0]["online"])

	av := call(t, ali, "refresh", nil)
	helping := list(av, "helping")
	require.Len(t, helping, 1)
	assert.Equal(t, "Sara", helping[0]["name"], "the inviter's name opens with the pending claim's key")
	assert.Equal(t, true, av["new_helping"])
	assert.Empty(t, list(av, "claims"))
	assert.Equal(t, false, call(t, ali, "refresh", nil)["new_helping"], "only the first refresh reports it")

	again := newTestEngine(t, cloud, "ali-device", aliDir)
	assert.Equal(t, "Sara", list(call(t, again, "view", nil), "helping")[0]["name"], "names survive a restart")

	call(t, sara, "end_pairing", map[string]any{"pairing_id": helpers[0]["pairing_id"]})
	assert.Empty(t, list(call(t, sara, "view", nil), "helpers"))
	assert.Empty(t, list(call(t, ali, "refresh", nil), "helping"), "the other side learns at its next refresh")
}

func TestASecondClaimIsAlreadyClaimed(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
	call(t, newTestEngine(t, cloud, "eve", t.TempDir()), "claim", map[string]any{"link": link, "name": "Eve"})
	assert.Equal(t, CodeAlreadyClaimed,
		callErr(t, newTestEngine(t, cloud, "ali", t.TempDir()), "claim", map[string]any{"link": link, "name": "Ali"}))
}

func TestRejectBurnsTheInvite(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
	call(t, newTestEngine(t, cloud, "eve", t.TempDir()), "claim", map[string]any{"link": link, "name": "Eve"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	sv := call(t, sara, "decide", map[string]any{"invite_id": id, "approve": false})
	assert.Empty(t, list(sv, "invites"))
	assert.Empty(t, list(sv, "helpers"))
	assert.Equal(t, CodeAlreadyClaimed,
		callErr(t, newTestEngine(t, cloud, "ali", t.TempDir()), "claim", map[string]any{"link": link, "name": "Ali"}))
}

func TestClaimRefusals(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
	assert.Equal(t, CodeOwnInvite, callErr(t, sara, "claim", map[string]any{"link": link, "name": "Sara"}))
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	assert.Equal(t, CodeBadLink, callErr(t, ali, "claim", map[string]any{"link": "https://evil.example/#x", "name": "Ali"}))
	assert.Equal(t, CodeBadName, callErr(t, ali, "claim", map[string]any{"link": link, "name": "  "}))
	assert.Equal(t, CodeBadName, callErr(t, sara, "create_invite", map[string]any{"name": ""}))
	first := call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	second := call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	assert.Equal(t, first, second, "claiming the same link again returns the same claim")
}

func TestStatusErrors(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	cloud.disabled = true
	assert.Equal(t, CodeDisabled, callErr(t, sara, "create_invite", map[string]any{"name": "Sara"}))
	cloud.disabled, cloud.down = false, true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "refresh", nil))
	fresh := NewEngine(t.TempDir(), cloud.relay("x"), nil)
	assert.Equal(t, CodeLocked, callErr(t, fresh, "view", nil))
	assert.JSONEq(t, `{"error":"locked"}`, ErrorJSON(&Error{Code: CodeLocked}))
	assert.JSONEq(t, `{"error":"internal"}`, ErrorJSON(errors.New("boom")))
}

func TestDescribeCarriesTheStatus(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	cloud.disabled = true
	_, err := sara.Call(context.Background(), "create_invite", mustJSON(map[string]any{"name": "Sara"}))
	code, status := Describe(err)
	assert.Equal(t, CodeDisabled, code)
	assert.Equal(t, 404, status)

	code, status = Describe(statusError("invites", 400, "bad request"))
	assert.Equal(t, CodeInternal, code)
	assert.Equal(t, 400, status)

	code, status = Describe(errors.New("boom"))
	assert.Equal(t, CodeInternal, code)
	assert.Zero(t, status)
}

func TestMalformedAnswersCarryTheStatus(t *testing.T) {
	answer := []byte("not json")
	e := NewEngine(t.TempDir(), func(context.Context, string, []byte) (int, []byte, string, error) {
		return 200, answer, "", nil
	}, nil)
	var raw map[string]json.RawMessage
	code, status := Describe(e.post(context.Background(), "pairings", struct{}{}, &raw))
	assert.Equal(t, CodeUnavailable, code)
	assert.Equal(t, 200, status)

	answer = []byte(`{}`)
	_, err := e.listPairings(context.Background())
	code, status = Describe(err)
	assert.Equal(t, CodeUnavailable, code)
	assert.Equal(t, 200, status)
}

func TestStateIsSealed(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	sara := newTestEngine(t, cloud, "sara", dir)
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
	secret := strings.TrimPrefix(link, helperinvite.LinkPrefix)
	data, err := os.ReadFile(filepath.Join(dir, stateFile))
	require.NoError(t, err)
	assert.NotContains(t, string(data), "Sara")
	assert.NotContains(t, string(data), secret)
	info, err := os.Stat(filepath.Join(dir, stateFile))
	require.NoError(t, err)
	if os.PathSeparator == '/' {
		assert.Equal(t, os.FileMode(0o600), info.Mode().Perm())
	}

	other := NewEngine(dir, cloud.relay("sara"), nil)
	out := call(t, other, "unlock", map[string]any{"key": base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{2}, 32))})
	assert.Empty(t, list(out, "invites"), "another key reads nothing")
	assert.Equal(t, true, out["keystore_reset"], "and says so rather than silently starting over")
	assert.FileExists(t, filepath.Join(dir, stateFile+".bak"), "the unreadable state is kept")
	assert.Nil(t, call(t, other, "view", nil)["keystore_reset"], "reported once, at unlock")
}

// TestVolunteerAbroadWithoutTheFlag covers a volunteer that lantern-cloud
// gates by its claim or pairing (Task 1): after its claim is rejected, and
// after its last pairing ends, the gate answers 404, and the engine must
// read that as "nothing", not as an error that strands the claim or row.
func TestVolunteerAbroadWithoutTheFlag(t *testing.T) {
	cloud := newFakeCloud()
	cloud.flagOff["ali"] = true
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())

	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	assert.Len(t, list(call(t, ali, "refresh", nil), "claims"), 1, "a live claim passes the gate")
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	call(t, sara, "decide", map[string]any{"invite_id": id, "approve": false})
	assert.Empty(t, list(call(t, ali, "refresh", nil), "claims"), "the rejected claim is dropped, not left waiting")

	link = call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id = list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	call(t, sara, "decide", map[string]any{"invite_id": id, "approve": true})
	require.Len(t, list(call(t, ali, "refresh", nil), "helping"), 1)
	pid := list(call(t, sara, "view", nil), "helpers")[0]["pairing_id"]
	call(t, sara, "end_pairing", map[string]any{"pairing_id": pid})
	assert.Empty(t, list(call(t, ali, "refresh", nil), "helping"), "the ended pairing's row is removed")
}

// TestCancelledInviteRejectsALaterClaim covers the tombstone: a cancelled,
// unclaimed invite is hidden, and a claim that arrives later is rejected at
// the next refresh instead of waiting for an approval that cannot come.
func TestCancelledInviteRejectsALaterClaim(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	inv := call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	sv := call(t, sara, "forget_invite", map[string]any{"invite_id": inv["invite_id"]})
	assert.Empty(t, list(sv, "invites"), "a cancelled invite is hidden")
	call(t, newTestEngine(t, cloud, "eve", t.TempDir()), "claim", map[string]any{"link": inv["link"], "name": "Eve"})
	assert.Empty(t, list(call(t, sara, "refresh", nil), "invites"))
	assert.Empty(t, list(call(t, sara, "view", nil), "helpers"))
	cloud.mu.Lock()
	defer cloud.mu.Unlock()
	for _, fi := range cloud.invites {
		assert.Equal(t, "rejected", fi.state, "the late claim was rejected")
	}
}

// TestEachInviteKeepsItsOwnName checks that approval seals the name given for
// that invite, not whichever name was typed last.
func TestEachInviteKeepsItsOwnName(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	first := call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	call(t, sara, "create_invite", map[string]any{"name": "S. from work"})
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	call(t, ali, "claim", map[string]any{"link": first["link"], "name": "Ali"})
	for _, iv := range list(call(t, sara, "refresh", nil), "invites") {
		if iv["state"] == "claimed" {
			call(t, sara, "decide", map[string]any{"invite_id": iv["id"], "approve": true})
		}
	}
	assert.Equal(t, "Sara", list(call(t, ali, "refresh", nil), "helping")[0]["name"])
}

func TestExpiredInvitesAndClaimsArePruned(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	later := time.Now().Add(InviteTTL + time.Hour)
	sara.now = func() time.Time { return later }
	ali.now = func() time.Time { return later }
	assert.Empty(t, list(call(t, sara, "refresh", nil), "invites"))
	assert.Empty(t, list(call(t, ali, "refresh", nil), "claims"))
}

func TestEndAllHelpers(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	for _, v := range []string{"ali", "bo"} {
		link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
		call(t, newTestEngine(t, cloud, v, t.TempDir()), "claim", map[string]any{"link": link, "name": v})
		inv := list(call(t, sara, "refresh", nil), "invites")
		call(t, sara, "decide", map[string]any{"invite_id": inv[0]["id"], "approve": true})
	}
	call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	require.Len(t, list(call(t, sara, "view", nil), "helpers"), 2)
	sv := call(t, sara, "end_all_helpers", nil)
	assert.Empty(t, list(sv, "helpers"))
	assert.Empty(t, list(sv, "invites"))
	assert.Empty(t, cloud.pairings)
}

func TestRefreshReadsActivity(t *testing.T) {
	cloud := newFakeCloud()
	e := NewEngine(t.TempDir(), cloud.relay("ali"), func(context.Context) (Activity, error) {
		return Activity{Day: "2026-10-23", ActiveSeconds: 3600, RelayedBytes: 42}, nil
	})
	call(t, e, "unlock", map[string]any{"key": testKey})
	act := call(t, e, "refresh", nil)["activity"].(map[string]any)
	assert.Equal(t, "2026-10-23", act["day"])
	assert.Equal(t, float64(3600), act["active_seconds"])
	assert.Equal(t, float64(42), act["relayed_bytes"])
}

// TestMalformedVolunteerKeyIsUnavailable covers a server answer whose volunteer
// key is not 32 bytes: MatchingCode returns "" and NewApproval ErrKey. Both
// are a malformed answer from lantern-cloud, never a claimed invite with an
// empty code, and never bad_name.
func TestMalformedVolunteerKeyIsUnavailable(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
	call(t, newTestEngine(t, cloud, "ali", t.TempDir()), "claim", map[string]any{"link": link, "name": "Ali"})
	cloud.mu.Lock()
	for _, fi := range cloud.invites {
		fi.volunteerPub = fi.volunteerPub[:16]
	}
	cloud.mu.Unlock()
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "refresh", nil))
	iv := list(call(t, sara, "view", nil), "invites")
	require.Len(t, iv, 1)
	assert.Equal(t, "pending", iv[0]["state"], "not shown as claimed")
	assert.Nil(t, iv[0]["code"])

	sara.st.Invites[0].State = "claimed"
	sara.st.Invites[0].VolunteerPub = bytes.Repeat([]byte{7}, 16)
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide",
		map[string]any{"invite_id": sara.st.Invites[0].ID, "approve": true}))
	assert.Len(t, list(call(t, sara, "view", nil), "invites"), 1, "the invite is kept")
	assert.Empty(t, list(call(t, sara, "view", nil), "helpers"))
}

// pair makes sara's invite, claimed by device "ali" as Ali and approved.
func pair(t *testing.T, cloud *fakeCloud, sara *Engine, aliDir string) *Engine {
	t.Helper()
	ali := newTestEngine(t, cloud, "ali", aliDir)
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	call(t, sara, "decide", map[string]any{"invite_id": id, "approve": true})
	return ali
}

// TestInviterKeepsHelpersWhenTheGateSaysDisabled: a 404 from the gate to an
// inviter with no open invites drops only the volunteer side.
func TestInviterKeepsHelpersWhenTheGateSaysDisabled(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	pair(t, cloud, sara, t.TempDir())
	cloud.outboundTag["ali"] = "helper-0123456789ab"
	cloud.online["ali"] = true
	call(t, sara, "refresh", nil)
	cloud.flagOff["sara"] = true
	helpers := list(call(t, sara, "refresh", nil), "helpers")
	require.Len(t, helpers, 1, "the helper row is kept")
	assert.Equal(t, "Ali", helpers[0]["name"])
	assert.Equal(t, "helper-0123456789ab", helpers[0]["outbound_tag"], "the helper keeps its tag")
	assert.Equal(t, true, helpers[0]["online"], "and its online state")
	cloud.flagOff["sara"] = false
	call(t, sara, "end_pairing", map[string]any{"pairing_id": helpers[0]["pairing_id"]})
	assert.Empty(t, cloud.pairings)
}

func TestClaimAnswerLostThenRetried(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	cloud.loseAnswer["invites/claim"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, ali, "claim", map[string]any{"link": link, "name": "Ali"}))
	cl := call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	assert.Equal(t, cl, call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"}))
	require.Len(t, cloud.bodies["invites/claim"], 2, "the confirmed claim is not sent again")
	assert.Equal(t, cloud.bodies["invites/claim"][0], cloud.bodies["invites/claim"][1], "the retry is the same request, same seed")
	inv := list(call(t, sara, "refresh", nil), "invites")[0]
	assert.Equal(t, cl["code"], inv["code"])
	call(t, sara, "decide", map[string]any{"invite_id": inv["id"], "approve": true})
	assert.Equal(t, "Sara", list(call(t, ali, "refresh", nil), "helping")[0]["name"])
}

func TestClaimNeverSentThenRetried(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	aliDir := t.TempDir()
	ali := newTestEngine(t, cloud, "ali", aliDir)
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	cloud.down = true
	assert.Equal(t, CodeUnavailable, callErr(t, ali, "claim", map[string]any{"link": link, "name": "Ali"}))
	cloud.down = false
	ali = newTestEngine(t, cloud, "ali", aliDir) // the provisional claim survives a restart
	cl := call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	assert.Equal(t, cloud.bodies["invites/claim"][0], cloud.bodies["invites/claim"][1])
	assert.Equal(t, cl["code"], list(call(t, sara, "refresh", nil), "invites")[0]["code"])
}

func TestClaimFirstAttemptConflictLeavesNoClaim(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, newTestEngine(t, cloud, "eve", t.TempDir()), "claim", map[string]any{"link": link, "name": "Eve"})
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	assert.Equal(t, CodeAlreadyClaimed, callErr(t, ali, "claim", map[string]any{"link": link, "name": "Ali"}))
	assert.Empty(t, list(call(t, ali, "view", nil), "claims"))
	assert.Equal(t, CodeAlreadyClaimed, callErr(t, ali, "claim", map[string]any{"link": link, "name": "Ali"}),
		"a dropped provisional claim does not turn a later 409 into success")
}

func TestApproveWithoutPairingID(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, newTestEngine(t, cloud, "ali", t.TempDir()), "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	cloud.noPairingID = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	inv := list(call(t, sara, "view", nil), "invites")
	require.Len(t, inv, 1)
	assert.Equal(t, "claimed", inv[0]["state"])
	assert.Equal(t, "Ali", inv[0]["volunteer_name"])
	cloud.noPairingID = false
	assert.Equal(t, CodeNoPendingClaim, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	assert.Len(t, list(call(t, sara, "view", nil), "invites"), 1, "a retry keeps the invite")
	sv := call(t, sara, "refresh", nil)
	assert.Empty(t, list(sv, "invites"))
	require.Len(t, list(sv, "helpers"), 1)
	assert.Equal(t, "Ali", list(sv, "helpers")[0]["name"])
}

func TestRefreshApprovedWithoutPairingID(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, newTestEngine(t, cloud, "ali", t.TempDir()), "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	cloud.noPairingID = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "refresh", nil))
	assert.Len(t, list(call(t, sara, "view", nil), "invites"), 1, "the invite and its name are kept")
	cloud.noPairingID = false
	sv := call(t, sara, "refresh", nil)
	assert.Empty(t, list(sv, "invites"))
	require.Len(t, list(sv, "helpers"), 1)
	assert.Equal(t, "Ali", list(sv, "helpers")[0]["name"])
}

// TestLateApprovalStillNamed: an approval seen only after the 48 hours have
// passed still names the pairing on both sides.
func TestLateApprovalStillNamed(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	cloud.loseAnswer["invites/decide"] = true
	callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true})
	later := time.Now().Add(InviteTTL + time.Hour)
	sara.now = func() time.Time { return later }
	ali.now = func() time.Time { return later }
	assert.Equal(t, "Ali", list(call(t, sara, "refresh", nil), "helpers")[0]["name"])
	assert.Equal(t, "Sara", list(call(t, ali, "refresh", nil), "helping")[0]["name"])
}

func TestUnreadableStateStaysLocked(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	require.NoError(t, os.Mkdir(filepath.Join(dir, stateFile), 0o700)) // reads fail, not as missing
	e := NewEngine(dir, cloud.relay("sara"), nil)
	assert.Equal(t, CodeInternal, callErr(t, e, "unlock", map[string]any{"key": testKey}))
	assert.Equal(t, CodeLocked, callErr(t, e, "view", nil))
}

func TestBackupsAreNotOverwritten(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	path := filepath.Join(dir, stateFile)
	require.NoError(t, os.WriteFile(path, []byte("first unreadable state"), 0o600))
	call(t, NewEngine(dir, cloud.relay("sara"), nil), "unlock", map[string]any{"key": testKey})
	require.NoError(t, os.WriteFile(path, []byte("second unreadable state"), 0o600))
	out := call(t, NewEngine(dir, cloud.relay("sara"), nil), "unlock", map[string]any{"key": testKey})
	assert.Equal(t, true, out["keystore_reset"])
	first, err := os.ReadFile(path + ".bak")
	require.NoError(t, err)
	assert.Equal(t, "first unreadable state", string(first))
	second, err := os.ReadFile(path + ".bak.1")
	require.NoError(t, err)
	assert.Equal(t, "second unreadable state", string(second))
}

func TestResetRefusedWhenBackupFails(t *testing.T) {
	if os.PathSeparator != '/' || os.Geteuid() == 0 {
		t.Skip("needs POSIX permissions and a non-root user")
	}
	cloud := newFakeCloud()
	dir := t.TempDir()
	path := filepath.Join(dir, stateFile)
	require.NoError(t, os.WriteFile(path, []byte("unreadable state"), 0o600))
	require.NoError(t, os.Chmod(dir, 0o500))
	t.Cleanup(func() { _ = os.Chmod(dir, 0o700) })
	e := NewEngine(dir, cloud.relay("sara"), nil)
	assert.Equal(t, CodeInternal, callErr(t, e, "unlock", map[string]any{"key": testKey}))
	assert.Equal(t, CodeLocked, callErr(t, e, "create_invite", map[string]any{"name": "Sara"}))
	data, err := os.ReadFile(path)
	require.NoError(t, err)
	assert.Equal(t, "unreadable state", string(data))
}

func TestEndAllHelpersOfflineWipesNames(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	sara := newTestEngine(t, cloud, "sara", dir)
	pair(t, cloud, sara, t.TempDir())
	cloud.down = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "end_all_helpers", nil))
	for _, e := range []*Engine{sara, newTestEngine(t, cloud, "sara", dir)} {
		helpers := list(call(t, e, "view", nil), "helpers")
		require.Len(t, helpers, 1)
		assert.Equal(t, "", helpers[0]["name"])
	}
	cloud.down = false
	assert.Empty(t, list(call(t, sara, "end_all_helpers", nil), "helpers"))
}

func TestSaveTightensPermissions(t *testing.T) {
	if os.PathSeparator != '/' {
		t.Skip("POSIX permissions")
	}
	cloud := newFakeCloud()
	dir := filepath.Join(t.TempDir(), "helper")
	require.NoError(t, os.Mkdir(dir, 0o755))
	require.NoError(t, os.WriteFile(filepath.Join(dir, stateFile+".tmp"), nil, 0o644))
	sara := newTestEngine(t, cloud, "sara", dir)
	call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	info, err := os.Stat(dir)
	require.NoError(t, err)
	assert.Equal(t, os.FileMode(0o700), info.Mode().Perm())
	info, err = os.Stat(filepath.Join(dir, stateFile))
	require.NoError(t, err)
	assert.Equal(t, os.FileMode(0o600), info.Mode().Perm())
}

// TestFailedTombstoneRejectChangesNothing: when the reject of a late claim
// fails, refresh keeps the tombstone and does not rewrite the state.
func TestFailedTombstoneRejectChangesNothing(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	sara := newTestEngine(t, cloud, "sara", dir)
	inv := call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	call(t, sara, "forget_invite", map[string]any{"invite_id": inv["invite_id"]})
	call(t, newTestEngine(t, cloud, "eve", t.TempDir()), "claim", map[string]any{"link": inv["link"], "name": "Eve"})
	before, err := os.ReadFile(filepath.Join(dir, stateFile))
	require.NoError(t, err)
	cloud.fail["invites/decide"] = 503
	call(t, sara, "refresh", nil)
	after, err := os.ReadFile(filepath.Join(dir, stateFile))
	require.NoError(t, err)
	assert.Equal(t, before, after, "nothing changed, so nothing was saved")
	require.Len(t, sara.st.Invites, 1)
	delete(cloud.fail, "invites/decide")
	call(t, sara, "refresh", nil)
	assert.Empty(t, sara.st.Invites, "the next refresh rejects it")
}

func relayCalls(cloud *fakeCloud) int {
	cloud.mu.Lock()
	defer cloud.mu.Unlock()
	n := 0
	for _, b := range cloud.bodies {
		n += len(b)
	}
	return n
}

// TestRefreshReportsHelpersChanged: a refresh that adds or drops a pairing in
// which this device is helped says so, so the app fetches the config that
// carries (or no longer carries) that helper's route. Other refreshes do not.
func TestRefreshReportsHelpersChanged(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	sv := call(t, sara, "refresh", nil)
	assert.Nil(t, sv["helpers_changed"], "a claim is not a helper yet")
	id := list(sv, "invites")[0]["id"]

	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	sv = call(t, sara, "refresh", nil)
	require.Len(t, list(sv, "helpers"), 1)
	assert.Equal(t, true, sv["helpers_changed"], "the approval whose answer was lost adds a helper")
	assert.Nil(t, call(t, sara, "refresh", nil)["helpers_changed"], "only the refresh that saw it")

	av := call(t, ali, "refresh", nil)
	assert.Equal(t, true, av["new_helping"])
	assert.Nil(t, av["helpers_changed"], "a pairing this device volunteers in is not a helper")

	pid := list(av, "helping")[0]["pairing_id"]
	call(t, ali, "end_pairing", map[string]any{"pairing_id": pid})
	sv = call(t, sara, "refresh", nil)
	assert.Empty(t, list(sv, "helpers"))
	assert.Equal(t, true, sv["helpers_changed"], "a helper the other side ended is dropped")
	assert.Nil(t, call(t, sara, "refresh", nil)["helpers_changed"])
}

// TestReclaimWhilePairedIsAlreadyHelping: re-opening the link of an invite
// this device already helps for (a re-tap in chat, or Android relaunching
// with the original intent) must not post a second claim, whose 409 would
// read as a link someone else used.
func TestReclaimWhilePairedIsAlreadyHelping(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	aliDir := t.TempDir()
	ali := newTestEngine(t, cloud, "ali", aliDir)
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	call(t, sara, "decide", map[string]any{"invite_id": id, "approve": true})
	av := call(t, ali, "refresh", nil)
	require.Len(t, list(av, "helping"), 1)
	assert.Empty(t, list(av, "claims"))
	assert.Nil(t, list(av, "helping")[0]["invite_hash"], "the hash stays in the sealed state")

	before := relayCalls(cloud)
	assert.Equal(t, CodeAlreadyHelping, callErr(t, ali, "claim", map[string]any{"link": link, "name": "Ali"}))
	again := newTestEngine(t, cloud, "ali", aliDir)
	assert.Equal(t, CodeAlreadyHelping, callErr(t, again, "claim", map[string]any{"link": link, "name": "Ali"}),
		"the hash survives a restart")
	assert.Equal(t, before, relayCalls(cloud), "nothing is sent")
}

// TestReclaimPendingClaimReturnsItsCode: re-opening the link of a claim that
// is waiting for approval shows the same code and sends nothing.
func TestReclaimPendingClaimReturnsItsCode(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	aliDir := t.TempDir()
	ali := newTestEngine(t, cloud, "ali", aliDir)
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	first := call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	before := relayCalls(cloud)
	assert.Equal(t, first, call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"}))
	assert.Equal(t, first, call(t, newTestEngine(t, cloud, "ali", aliDir), "claim",
		map[string]any{"link": link, "name": "someone else"}))
	assert.Equal(t, before, relayCalls(cloud), "nothing is sent")
}

// TestStateWithoutInviteHashesLoads: a state file written before pairings
// kept their invite hash opens, and its pairings match no link.
func TestStateWithoutInviteHashesLoads(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	key := bytes.Repeat([]byte{1}, 32)
	aead, err := chacha20poly1305.New(key)
	require.NoError(t, err)
	old := `{"v":1,"my_name":"Ali","pairings":[{"id":"p1","role":"volunteer","name":"Sara","since":"2026-10-01T00:00:00Z"}]}`
	nonce := make([]byte, chacha20poly1305.NonceSize)
	require.NoError(t, os.WriteFile(filepath.Join(dir, stateFile),
		aead.Seal(nonce, nonce, []byte(old), []byte(stateAD)), 0o600))

	ali := NewEngine(dir, cloud.relay("ali"), nil)
	out := call(t, ali, "unlock", map[string]any{"key": testKey})
	assert.Nil(t, out["keystore_reset"])
	helping := list(out, "helping")
	require.Len(t, helping, 1)
	assert.Equal(t, "Sara", helping[0]["name"])

	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	assert.Regexp(t, `^[0-9]{4}$`, call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})["code"])
}

// TestExpiredInviteOfFlagOffInviterIsPruned: once the inviter's flag is off,
// invites/get answers the gate's 404. An invite past its expiry is forgotten
// rather than failing every refresh; one still within it keeps failing, so
// nothing is dropped that could still be decided.
func TestExpiredInviteOfFlagOffInviterIsPruned(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	cloud.flagOff["sara"] = true
	assert.Equal(t, CodeDisabled, callErr(t, sara, "refresh", nil))
	require.Len(t, sara.st.Invites, 1)
	later := time.Now().Add(InviteTTL + time.Hour)
	sara.now = func() time.Time { return later }
	assert.Empty(t, list(call(t, sara, "refresh", nil), "invites"))
	assert.Empty(t, sara.st.Invites)
}

func TestInviteViewCarriesItsOwnName(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	call(t, sara, "create_invite", map[string]any{"name": "S. from work"})
	iv := list(call(t, sara, "view", nil), "invites")
	require.Len(t, iv, 2)
	assert.Equal(t, "Sara", iv[0]["inviter_name"])
	assert.Equal(t, "S. from work", iv[1]["inviter_name"])
}

func TestViewMarksProvisionalClaims(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	cloud.down = true
	assert.Equal(t, CodeUnavailable, callErr(t, ali, "claim", map[string]any{"link": link, "name": "Ali"}))
	claims := list(call(t, ali, "view", nil), "claims")
	require.Len(t, claims, 1)
	assert.Equal(t, true, claims[0]["provisional"], "not yet known to have reached the inviter")
	cloud.down = false
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	claims = list(call(t, ali, "view", nil), "claims")
	require.Len(t, claims, 1)
	assert.Nil(t, claims[0]["provisional"], "a confirmed claim is not marked")
}

// TestHelpersChangedSurvivesAFailedRefresh: a refresh that adds a helper and
// then fails must not lose the news. The next successful refresh reports it,
// once.
func TestHelpersChangedSurvivesAFailedRefresh(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]

	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	cloud.fail["pairings"] = 500
	callErr(t, sara, "refresh", nil)
	require.Len(t, list(call(t, sara, "view", nil), "helpers"), 1, "the failed refresh saved the approval")

	delete(cloud.fail, "pairings")
	sv := call(t, sara, "refresh", nil)
	require.Len(t, list(sv, "helpers"), 1)
	assert.Equal(t, true, sv["helpers_changed"], "the helper the failed refresh added")
	assert.Nil(t, call(t, sara, "refresh", nil)["helpers_changed"], "reported once")
}

// TestMergeSkipsEntriesWithoutPairingID: a listed pairing without an id is
// malformed; it is neither added nor reported as a new pairing to help in.
func TestMergeSkipsEntriesWithoutPairingID(t *testing.T) {
	e := newTestEngine(t, newFakeCloud(), "ali", t.TempDir())
	changed := e.mergePairings([]listedPairing{{Role: RoleVolunteer}, {Role: RoleInviter}})
	assert.False(t, changed)
	assert.False(t, e.newHelpingPending)
	assert.Empty(t, e.st.Pairings)
}

// TestEndAllHelpersEndsAPairingKnownOnlyRemotely: an approval whose answer
// was lost leaves a pairing this device never recorded. Remove all drops the
// invite (its claim is no longer pending) and still ends that pairing.
func TestEndAllHelpersEndsAPairingKnownOnlyRemotely(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	require.Len(t, cloud.pairings, 1)
	assert.Empty(t, list(call(t, sara, "view", nil), "helpers"))

	cloud.fail["pairings/end"] = 503
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "end_all_helpers", nil), "a failed end is reported")
	require.Len(t, cloud.pairings, 1)
	helpers := list(call(t, sara, "view", nil), "helpers")
	require.Len(t, helpers, 1, "the pairing still in force is shown")
	assert.Equal(t, "", helpers[0]["name"])

	delete(cloud.fail, "pairings/end")
	sv := call(t, sara, "end_all_helpers", nil)
	assert.Empty(t, cloud.pairings)
	assert.Empty(t, list(sv, "helpers"))
	assert.Empty(t, list(sv, "invites"))
	assert.Equal(t, true, call(t, sara, "refresh", nil)["helpers_changed"], "the config drops its route")
}

// approvedClaim has ali claim bo's invite and bo approve it, so ali's next
// pairings list carries a new pairing to help in.
func approvedClaim(t *testing.T, cloud *fakeCloud, ali *Engine) {
	t.Helper()
	bo := newTestEngine(t, cloud, "bo", t.TempDir())
	link := call(t, bo, "create_invite", map[string]any{"name": "Bo"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, bo, "refresh", nil), "invites")[0]["id"]
	call(t, bo, "decide", map[string]any{"invite_id": id, "approve": true})
}

// TestNewHelpingSurvivesAFailedRefresh: a refresh that merges a new pairing
// to help in, consuming its claim, and then fails still reports it, once, in
// the next view.
func TestNewHelpingSurvivesAFailedRefresh(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	ali := newTestEngine(t, cloud, "ali", dir)
	approvedClaim(t, cloud, ali)
	// A directory where the state file goes makes the save fail.
	stateFilePath := filepath.Join(dir, stateFile)
	require.NoError(t, os.Remove(stateFilePath))
	require.NoError(t, os.MkdirAll(filepath.Join(stateFilePath, "x"), 0o700))
	assert.Equal(t, CodeInternal, callErr(t, ali, "refresh", nil))
	assert.Empty(t, ali.st.Claims, "the claim was consumed")
	require.NoError(t, os.RemoveAll(stateFilePath))

	v := call(t, ali, "view", nil)
	assert.Equal(t, true, v["new_helping"])
	assert.Equal(t, "Bo", list(v, "helping")[0]["name"])
	assert.Equal(t, false, call(t, ali, "view", nil)["new_helping"], "once only")
	assert.Equal(t, false, call(t, ali, "refresh", nil)["new_helping"])
}

// TestNewHelpingSurvivesAFailedEndAll: remove all merges the volunteer side
// of the pairings it lists; when it then fails, the new pairing to help in is
// still reported, once, by the next view.
func TestNewHelpingSurvivesAFailedEndAll(t *testing.T) {
	cloud := newFakeCloud()
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	// A pairing in which ali is helped that only lantern-cloud knows of.
	link := call(t, ali, "create_invite", map[string]any{"name": "Ali"})["link"]
	call(t, newTestEngine(t, cloud, "eve", t.TempDir()), "claim", map[string]any{"link": link, "name": "Eve"})
	id := list(call(t, ali, "refresh", nil), "invites")[0]["id"]
	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, ali, "decide", map[string]any{"invite_id": id, "approve": true}))
	approvedClaim(t, cloud, ali)

	cloud.fail["pairings/end"] = 503
	assert.Equal(t, CodeUnavailable, callErr(t, ali, "end_all_helpers", nil))
	assert.Empty(t, ali.st.Claims, "the claim was consumed")
	delete(cloud.fail, "pairings/end")

	v := call(t, ali, "view", nil)
	assert.Equal(t, true, v["new_helping"])
	assert.Equal(t, "Bo", list(v, "helping")[0]["name"])
	assert.Equal(t, false, call(t, ali, "view", nil)["new_helping"], "once only")
}

// TestAFailedSaveIsRetriedByTheNextOp: a refresh merges a new pairing to
// help in, consuming its claim and the one-time inviter blob, then cannot
// save. The next op, a read-only view, saves it, so a restart keeps it.
func TestAFailedSaveIsRetriedByTheNextOp(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	ali := newTestEngine(t, cloud, "ali", dir)
	approvedClaim(t, cloud, ali)
	stateFilePath := filepath.Join(dir, stateFile)
	require.NoError(t, os.Remove(stateFilePath))
	require.NoError(t, os.MkdirAll(filepath.Join(stateFilePath, "x"), 0o700))
	assert.Equal(t, CodeInternal, callErr(t, ali, "refresh", nil))
	assert.Equal(t, CodeInternal, callErr(t, ali, "refresh", nil), "a refresh while still dirty saves too")
	require.NoError(t, os.RemoveAll(stateFilePath))

	call(t, ali, "view", nil)
	again := newTestEngine(t, cloud, "ali", dir)
	require.Len(t, again.st.Pairings, 1)
	p := again.st.Pairings[0]
	assert.Equal(t, RoleVolunteer, p.Role)
	assert.Equal(t, "Bo", p.Name)
	assert.NotEmpty(t, p.InviteHash)
	assert.Empty(t, again.st.Claims)
}

// TestABlankListedIDDropsNothing: a listing with an entry that lacks its id
// may be missing a pairing this device holds, so no pairing (or its name)
// is dropped; the valid entries still merge.
func TestABlankListedIDDropsNothing(t *testing.T) {
	e := newTestEngine(t, newFakeCloud(), "ali", t.TempDir())
	e.addPairing("p1", RoleVolunteer, "Sara", time.Unix(1, 0), nil, nil)
	changed := e.mergePairings([]listedPairing{{Role: RoleVolunteer}, {PairingID: "p2", Role: RoleInviter}})
	assert.True(t, changed)
	require.Len(t, e.st.Pairings, 2)
	assert.Equal(t, "Sara", e.pairing("p1").Name)
	assert.NotNil(t, e.pairing("p2"))
	assert.True(t, e.mergePairings([]listedPairing{{PairingID: "p2", Role: RoleInviter}}), "a complete listing drops")
	assert.Nil(t, e.pairing("p1"))
}

// TestEndAllHelpersReportsADisabledListing: after a lost approval the
// pairing exists only in lantern-cloud. A remove all that dropped the invite
// but could not list leaves nothing local to end; with the flag then off the
// listing is the gate's 404, and remove all says so instead of succeeding.
func TestEndAllHelpersReportsADisabledListing(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, newTestEngine(t, cloud, "bo", t.TempDir()), "claim", map[string]any{"link": link, "name": "Bo"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	cloud.fail["pairings"] = 503
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "end_all_helpers", nil))
	delete(cloud.fail, "pairings")
	require.Empty(t, sara.st.Invites)
	require.Empty(t, sara.st.Pairings)

	cloud.flagOff["sara"] = true
	assert.Equal(t, CodeDisabled, callErr(t, sara, "end_all_helpers", nil))
	assert.Len(t, cloud.pairings, 1, "the pairing is still in force")
}

// TestEndAllHelpersReportsABlankListedHelper: a pairing only lantern-cloud
// knows of, listed without its id, cannot be ended, so remove all reports it
// rather than succeeding; the names are still erased.
func TestEndAllHelpersReportsABlankListedHelper(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	sara := newTestEngine(t, cloud, "sara", dir)
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, newTestEngine(t, cloud, "bo", t.TempDir()), "claim", map[string]any{"link": link, "name": "Bo"})
	inv := list(call(t, sara, "refresh", nil), "invites")[0]
	require.Equal(t, "Bo", inv["volunteer_name"])
	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": inv["id"], "approve": true}))
	cloud.blankInviterIDs = true

	assert.Equal(t, CodeUnavailable, callErr(t, sara, "end_all_helpers", nil))
	assert.Len(t, cloud.pairings, 1, "the pairing is still in force")
	for _, e := range []*Engine{sara, newTestEngine(t, cloud, "sara", dir)} {
		v := call(t, e, "view", nil)
		for _, h := range list(v, "helpers") {
			assert.Equal(t, "", h["name"])
		}
		assert.Empty(t, list(v, "invites"))
	}
}

// TestAListingWithoutPairingsIsUnavailable: lantern-cloud always sends the
// pairings key, so an answer without it is malformed. Refresh merges
// nothing and drops nothing; remove all does not report success.
func TestAListingWithoutPairingsIsUnavailable(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := pair(t, cloud, sara, t.TempDir())
	require.Len(t, list(call(t, ali, "refresh", nil), "helping"), 1)

	cloud.omitPairingsKey = true
	assert.Equal(t, CodeUnavailable, callErr(t, ali, "refresh", nil))
	helping := list(call(t, ali, "view", nil), "helping")
	require.Len(t, helping, 1, "the volunteer's pairing is kept")
	assert.Equal(t, "Sara", helping[0]["name"])
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "refresh", nil))
	require.Len(t, list(call(t, sara, "view", nil), "helpers"), 1)

	// A pairing only lantern-cloud knows of: remove all cannot see it.
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, newTestEngine(t, cloud, "bo", t.TempDir()), "claim", map[string]any{"link": link, "name": "Bo"})
	cloud.omitPairingsKey = false
	inv := list(call(t, sara, "refresh", nil), "invites")[0]
	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": inv["id"], "approve": true}))
	cloud.omitPairingsKey = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "end_all_helpers", nil))
	require.Len(t, cloud.pairings, 1, "ali's is ended; bo's, known only remotely, is still in force")
	assert.Equal(t, "bo", cloud.pairings[0].volunteer)

	cloud.omitPairingsKey = false
	assert.Empty(t, list(call(t, sara, "end_all_helpers", nil), "helpers"))
	assert.Empty(t, cloud.pairings)
}

// TestANullOrEmptyListingIsEmpty: null and [] are an empty list.
func TestANullOrEmptyListingIsEmpty(t *testing.T) {
	for _, body := range []string{`{"pairings":null}`, `{"pairings":[]}`} {
		relay := func(_ context.Context, op string, _ []byte) (int, []byte, string, error) {
			if op == "pairings" {
				return 200, []byte(body), "", nil
			}
			return 200, []byte("{}"), "", nil
		}
		e := NewEngine(t.TempDir(), relay, nil)
		call(t, e, "unlock", map[string]any{"key": testKey})
		e.addPairing("p1", RoleVolunteer, "Sara", time.Unix(1, 0), nil, nil)
		call(t, e, "refresh", nil)
		assert.Empty(t, e.st.Pairings, body)
		call(t, e, "end_all_helpers", nil)
	}
}

func TestRenameHelperIsLocalAndSurvivesRestarts(t *testing.T) {
	cloud := newFakeCloud()
	saraDir := t.TempDir()
	sara := newTestEngine(t, cloud, "sara", saraDir)
	ali := pair(t, cloud, sara, t.TempDir())
	id := list(call(t, sara, "view", nil), "helpers")[0]["pairing_id"]

	before := relayCalls(cloud)
	v := call(t, sara, "rename_helper", map[string]any{"pairing_id": id, "name": "  Cousin Ali "})
	assert.Equal(t, "Cousin Ali", list(v, "helpers")[0]["name"])
	assert.Equal(t, before, relayCalls(cloud), "a nickname never leaves the device")

	again := newTestEngine(t, cloud, "sara", saraDir)
	assert.Equal(t, "Cousin Ali", list(call(t, again, "refresh", nil), "helpers")[0]["name"],
		"kept across restarts and refreshes")

	v = call(t, again, "rename_helper", map[string]any{"pairing_id": id, "name": " "})
	assert.Equal(t, "Ali", list(v, "helpers")[0]["name"], "a blank name restores the friend's")

	assert.Equal(t, CodeBadName, callErr(t, again, "rename_helper", map[string]any{"pairing_id": id, "name": "a‮b"}))
	assert.Equal(t, CodeNotFound, callErr(t, again, "rename_helper", map[string]any{"pairing_id": "nope", "name": "X"}))
	helping := list(call(t, ali, "refresh", nil), "helping")[0]["pairing_id"]
	assert.Equal(t, CodeNotFound, callErr(t, ali, "rename_helper", map[string]any{"pairing_id": helping, "name": "X"}),
		"only the user's own personal proxies are renamed")
}

func TestRenameInviteNamesTheInviterAtApproval(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())

	inv := call(t, sara, "create_invite", map[string]any{"name": "Sara"})
	id := inv["invite_id"].(string)
	before := relayCalls(cloud)
	v := call(t, sara, "rename_invite", map[string]any{"invite_id": id, "name": "  Sara K "})
	assert.Equal(t, "Sara K", list(v, "invites")[0]["inviter_name"])
	assert.Equal(t, "Sara K", v["my_name"], "prefills the next invite")
	assert.Equal(t, before, relayCalls(cloud), "the name stays local until the approval")

	assert.Equal(t, CodeBadName, callErr(t, sara, "rename_invite", map[string]any{"invite_id": id, "name": " "}))
	assert.Equal(t, CodeBadName, callErr(t, sara, "rename_invite", map[string]any{"invite_id": id, "name": "a‮b"}))
	assert.Equal(t, CodeNotFound, callErr(t, sara, "rename_invite", map[string]any{"invite_id": "nope", "name": "X"}))

	call(t, ali, "claim", map[string]any{"link": inv["link"], "name": "Ali"})
	call(t, sara, "refresh", nil)
	call(t, sara, "decide", map[string]any{"invite_id": id, "approve": true})
	assert.Equal(t, "Sara K", list(call(t, ali, "refresh", nil), "helping")[0]["name"],
		"the friend sees the name as renamed")
	assert.Equal(t, CodeNotFound, callErr(t, sara, "rename_invite", map[string]any{"invite_id": id, "name": "X"}),
		"a decided invite is gone")
}

func TestEndAllHelpersErasesNicknames(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	sara := newTestEngine(t, cloud, "sara", dir)
	pair(t, cloud, sara, t.TempDir())
	id := list(call(t, sara, "view", nil), "helpers")[0]["pairing_id"]
	call(t, sara, "rename_helper", map[string]any{"pairing_id": id, "name": "Cousin"})
	// Offline, as in TestEndAllHelpersOfflineWipesNames: the names (and now
	// nicknames) go before any request.
	cloud.down = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "end_all_helpers", nil))
	for _, p := range newTestEngine(t, cloud, "sara", dir).st.Pairings {
		assert.Empty(t, p.Nickname)
		assert.Empty(t, p.Name)
	}
}

// TestABlankListedPairingKeepsItsTag: a listing with a blank pairing_id keeps
// the local pairings, so they keep the tag and online state the last
// complete listing gave them.
func TestABlankListedPairingKeepsItsTag(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	pair(t, cloud, sara, t.TempDir())
	cloud.outboundTag["ali"] = "helper-0123456789ab"
	cloud.online["ali"] = true
	require.Equal(t, "helper-0123456789ab", list(call(t, sara, "refresh", nil), "helpers")[0]["outbound_tag"])

	cloud.blankInviterIDs = true
	helpers := list(call(t, sara, "refresh", nil), "helpers")
	require.Len(t, helpers, 1, "the helper row is kept")
	assert.Equal(t, "helper-0123456789ab", helpers[0]["outbound_tag"])
	assert.Equal(t, true, helpers[0]["online"])
}

func TestInviterRowsCarryTheFriendsOutboundTag(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara-device", t.TempDir())
	ali := pair(t, cloud, sara, t.TempDir())

	helpers := list(call(t, sara, "refresh", nil), "helpers")
	require.Len(t, helpers, 1)
	assert.Nil(t, helpers[0]["outbound_tag"], "no tag until lantern-cloud gives one")

	cloud.outboundTag["ali"] = "helper-0123456789ab"
	helpers = list(call(t, sara, "refresh", nil), "helpers")
	assert.Equal(t, "helper-0123456789ab", helpers[0]["outbound_tag"])
	helpers = list(call(t, sara, "view", nil), "helpers")
	assert.Equal(t, "helper-0123456789ab", helpers[0]["outbound_tag"], "the view keeps the last list's tag")

	helping := list(call(t, ali, "refresh", nil), "helping")
	require.Len(t, helping, 1)
	assert.Nil(t, helping[0]["outbound_tag"], "a volunteer row never carries one")

	for _, bad := range []string{"helper-0123", "personal-proxies", "helper-0123456789AB", "x-0123456789ab"} {
		cloud.outboundTag["ali"] = bad
		helpers = list(call(t, sara, "refresh", nil), "helpers")
		assert.Nil(t, helpers[0]["outbound_tag"], "%q is not a helper tag", bad)
	}
}

// pairedWithSecret is pairedPair that also returns the invite secret, read
// from the link before approval.
func pairedWithSecret(t *testing.T, cloud *fakeCloud, inviterDir, volunteerDir string) (inviter, volunteer *Engine, pairingID string, secret []byte) {
	t.Helper()
	inviter = newTestEngine(t, cloud, "sara", inviterDir)
	volunteer = newTestEngine(t, cloud, "ali", volunteerDir)
	link := call(t, inviter, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
	secret, err := helperinvite.ParseLink(link)
	require.NoError(t, err)
	call(t, volunteer, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, inviter, "refresh", nil), "invites")[0]["id"]
	call(t, inviter, "decide", map[string]any{"invite_id": id, "approve": true})
	helping := list(call(t, volunteer, "refresh", nil), "helping")
	require.Len(t, helping, 1)
	return inviter, volunteer, helping[0]["pairing_id"].(string), secret
}

func TestBothSidesKeepThePairingKey(t *testing.T) {
	cloud := newFakeCloud()
	sara, ali, id, secret := pairedWithSecret(t, cloud, t.TempDir(), t.TempDir())
	want := helperinvite.PairingKey(secret)
	require.Len(t, want, 32)

	sk, ak := sara.PairingKeys(), ali.PairingKeys()
	require.Contains(t, sk, id)
	require.Contains(t, ak, id)
	assert.Equal(t, want, sk[id].Key)
	assert.Equal(t, want, ak[id].Key)
	assert.Equal(t, RoleInviter, sk[id].Role)
	assert.Equal(t, RoleVolunteer, ak[id].Role)

	assert.Equal(t, true, list(call(t, sara, "view", nil), "helpers")[0]["has_pairing_key"])
	assert.Equal(t, true, list(call(t, ali, "view", nil), "helping")[0]["has_pairing_key"])
}

func TestPairingKeyAfterALostApproval(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"].(string)
	secret, err := helperinvite.ParseLink(link)
	require.NoError(t, err)
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	assert.Empty(t, sara.PairingKeys())

	helpers := list(call(t, sara, "refresh", nil), "helpers")
	require.Len(t, helpers, 1)
	assert.Equal(t, true, helpers[0]["has_pairing_key"])
	keys := sara.PairingKeys()
	require.Len(t, keys, 1)
	assert.Equal(t, helperinvite.PairingKey(secret), keys[helpers[0]["pairing_id"].(string)].Key)
}

func TestPairingKeySurvivesARestartSealed(t *testing.T) {
	cloud := newFakeCloud()
	saraDir, aliDir := t.TempDir(), t.TempDir()
	_, _, id, secret := pairedWithSecret(t, cloud, saraDir, aliDir)
	key := helperinvite.PairingKey(secret)
	for _, dir := range []string{saraDir, aliDir} {
		data, err := os.ReadFile(filepath.Join(dir, stateFile))
		require.NoError(t, err)
		assert.False(t, bytes.Contains(data, key), "the key is not in the file in the clear")
		assert.NotContains(t, string(data), base64.StdEncoding.EncodeToString(key))

		locked := NewEngine(dir, cloud.relay("x"), nil)
		assert.Empty(t, locked.PairingKeys(), "nothing while locked")
		lockedKeys, unlocked := locked.UnlockedPairingKeys()
		assert.Empty(t, lockedKeys)
		assert.False(t, unlocked, "a locked engine says so")
		again := newTestEngine(t, cloud, "x", dir)
		assert.Equal(t, key, again.PairingKeys()[id].Key, "the key survives a restart")
		againKeys, unlocked := again.UnlockedPairingKeys()
		assert.True(t, unlocked)
		assert.Equal(t, key, againKeys[id].Key)
	}
}

func TestEndPairingDropsTheKeyOnBothSides(t *testing.T) {
	cloud := newFakeCloud()
	sara, ali, id, _ := pairedWithSecret(t, cloud, t.TempDir(), t.TempDir())
	call(t, sara, "end_pairing", map[string]any{"pairing_id": id})
	assert.Empty(t, sara.PairingKeys())
	assert.NotEmpty(t, ali.PairingKeys(), "until the other side refreshes")
	call(t, ali, "refresh", nil)
	assert.Empty(t, ali.PairingKeys(), "a server-side end drops it at the next refresh")

	cloud = newFakeCloud()
	sara, ali, id, _ = pairedWithSecret(t, cloud, t.TempDir(), t.TempDir())
	call(t, ali, "end_pairing", map[string]any{"pairing_id": id})
	assert.Empty(t, ali.PairingKeys())
	call(t, sara, "refresh", nil)
	assert.Empty(t, sara.PairingKeys())
}

func TestPairingKeysAreCopies(t *testing.T) {
	cloud := newFakeCloud()
	sara, _, id, secret := pairedWithSecret(t, cloud, t.TempDir(), t.TempDir())
	keys := sara.PairingKeys()
	keys[id].Key[0] ^= 0xff
	delete(keys, id)
	assert.Equal(t, helperinvite.PairingKey(secret), sara.PairingKeys()[id].Key)
	assert.Equal(t, helperinvite.PairingKey(secret), sara.pairing(id).PairingKey)
}

func TestOldStateHasNoPairingKey(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	key := bytes.Repeat([]byte{1}, 32)
	aead, err := chacha20poly1305.New(key)
	require.NoError(t, err)
	old := `{"v":1,"my_name":"Ali","pairings":[{"id":"p1","role":"volunteer","name":"Sara","since":"2026-10-01T00:00:00Z"},` +
		`{"id":"p2","role":"inviter","name":"Bo","since":"2026-10-01T00:00:00Z"}]}`
	nonce := make([]byte, chacha20poly1305.NonceSize)
	require.NoError(t, os.WriteFile(filepath.Join(dir, stateFile),
		aead.Seal(nonce, nonce, []byte(old), []byte(stateAD)), 0o600))

	ali := NewEngine(dir, cloud.relay("ali"), nil)
	out := call(t, ali, "unlock", map[string]any{"key": testKey})
	helping, helpers := list(out, "helping"), list(out, "helpers")
	require.Len(t, helping, 1)
	require.Len(t, helpers, 1)
	assert.Equal(t, false, helping[0]["has_pairing_key"])
	assert.Equal(t, false, helpers[0]["has_pairing_key"])
	assert.Empty(t, ali.PairingKeys())
}

func TestARemoteOnlyPairingHasNoKey(t *testing.T) {
	cloud := newFakeCloud()
	sara := newTestEngine(t, cloud, "sara", t.TempDir())
	ali := newTestEngine(t, cloud, "ali", t.TempDir())
	link := call(t, sara, "create_invite", map[string]any{"name": "Sara"})["link"]
	call(t, ali, "claim", map[string]any{"link": link, "name": "Ali"})
	id := list(call(t, sara, "refresh", nil), "invites")[0]["id"]
	cloud.loseAnswer["invites/decide"] = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "decide", map[string]any{"invite_id": id, "approve": true}))
	cloud.fail["pairings/end"] = 503
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "end_all_helpers", nil))
	helpers := list(call(t, sara, "view", nil), "helpers")
	require.Len(t, helpers, 1)
	assert.Equal(t, false, helpers[0]["has_pairing_key"])
	assert.Empty(t, sara.PairingKeys())
}

func TestEndAllHelpersErasesPairingKeys(t *testing.T) {
	cloud := newFakeCloud()
	dir := t.TempDir()
	sara := newTestEngine(t, cloud, "sara", dir)
	pair(t, cloud, sara, t.TempDir())
	require.Len(t, sara.PairingKeys(), 1)
	cloud.down = true
	assert.Equal(t, CodeUnavailable, callErr(t, sara, "end_all_helpers", nil))
	assert.Empty(t, sara.PairingKeys(), "the keys go with the names, before any request")
	for _, p := range newTestEngine(t, cloud, "sara", dir).st.Pairings {
		assert.Empty(t, p.PairingKey)
	}
}

func TestAddPairingFillsAMissingKey(t *testing.T) {
	e := NewEngine(t.TempDir(), nil, nil)
	e.addPairing("p", RoleInviter, "Ali", time.Now(), nil, nil)
	assert.Empty(t, e.pairing("p").PairingKey)
	e.addPairing("p", RoleInviter, "Ali", time.Now(), nil, []byte{1, 2})
	assert.Equal(t, []byte{1, 2}, e.pairing("p").PairingKey)
	e.addPairing("p", RoleInviter, "Ali", time.Now(), nil, []byte{3})
	assert.Equal(t, []byte{1, 2}, e.pairing("p").PairingKey, "a kept key is not replaced")
}

// TestRemoveAllRevokesKeysBeforeTheEndRequest: remove all erases the keys
// before it asks lantern-cloud to end anything, and the change is published
// then, so a stalled pairings/end does not keep a revoked key in radiance
// for the length of the op.
func TestRemoveAllRevokesKeysBeforeTheEndRequest(t *testing.T) {
	cloud := newFakeCloud()
	sara, _, id, _ := pairedWithSecret(t, cloud, t.TempDir(), t.TempDir())
	require.Contains(t, sara.PairingKeys(), id)

	stalled, release := make(chan struct{}), make(chan struct{})
	inner := sara.relay
	sara.relay = func(ctx context.Context, op string, body []byte) (int, []byte, string, error) {
		if op == "pairings/end" {
			close(stalled)
			<-release
		}
		return inner(ctx, op, body)
	}
	var mu sync.Mutex
	var seen []map[string]PairingKey
	sara.SetKeysChanged(func() {
		keys, unlocked := sara.UnlockedPairingKeys()
		assert.True(t, unlocked)
		mu.Lock()
		seen = append(seen, keys)
		mu.Unlock()
	})

	done := make(chan struct{})
	go func() {
		defer close(done)
		_, err := sara.Call(context.Background(), "end_all_helpers", nil)
		assert.NoError(t, err)
	}()
	<-stalled
	mu.Lock()
	require.NotEmpty(t, seen, "the change is published while pairings/end hangs")
	assert.NotContains(t, seen[len(seen)-1], id)
	mu.Unlock()
	keys, _ := sara.UnlockedPairingKeys()
	assert.NotContains(t, keys, id, "and a reader sees the reduced set")
	close(release)
	<-done
	assert.Empty(t, sara.PairingKeys())
}

func TestKeysChangedRunsOnlyOnAChange(t *testing.T) {
	cloud := newFakeCloud()
	e := NewEngine(t.TempDir(), cloud.relay("x"), nil)
	n := 0
	e.SetKeysChanged(func() { n++ })
	call(t, e, "unlock", map[string]any{"key": testKey})
	assert.Equal(t, 1, n, "the unlock is a change")
	call(t, e, "view", nil)
	call(t, e, "refresh", nil)
	assert.Equal(t, 1, n, "ops that change no key are not")
}
