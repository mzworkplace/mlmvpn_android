package mobile

import (
	"context"
	"errors"
	"sync/atomic"
	"testing"
	"time"
	"unicode/utf8"

	"github.com/getlantern/radiance/backend"
	"github.com/getlantern/radiance/ipc"
	"github.com/sagernet/sing-box/experimental/libbox"
)

func TestGetClientDoesNotWaitForIPCLifecycleLock(t *testing.T) {
	want := &ipc.Client{}
	previousClient := ipcClient.Swap(want)
	t.Cleanup(func() {
		ipcClient.Store(previousClient)
	})

	ipcLifecycle.mu.Lock()
	defer ipcLifecycle.mu.Unlock()

	result := make(chan *ipc.Client, 1)
	go func() {
		client, _ := getClient()
		result <- client
	}()

	select {
	case got := <-result:
		if got != want {
			t.Fatalf("getClient() = %p, want %p", got, want)
		}
	case <-time.After(time.Second):
		t.Fatal("getClient blocked on the IPC lifecycle lock")
	}
}

func TestResetNetworkWithoutClientIsNoop(t *testing.T) {
	previousClient := ipcClient.Swap(nil)
	t.Cleanup(func() {
		ipcClient.Store(previousClient)
	})
	if lanternCore.Load() != nil {
		t.Skip("lanternCore is initialized")
	}

	if err := ResetNetwork(); err != nil {
		t.Fatalf("ResetNetwork() error = %v, want nil", err)
	}
}

func TestResetNetworkForMonitorWithoutBackendIsNoop(t *testing.T) {
	withCleanIPCLifecycle(t)
	if err := ResetNetworkForMonitor(nil); err != nil {
		t.Fatalf("ResetNetworkForMonitor(nil) error = %v, want nil", err)
	}
}

func TestStartIPCServerReportsLifecycleBusy(t *testing.T) {
	ipcLifecycle.mu.Lock()
	previousServer := ipcLifecycle.server
	previousStartState := ipcLifecycle.startState
	previousClosing := ipcLifecycle.closing
	ipcLifecycle.server = nil
	ipcLifecycle.startState = ipcStarting
	ipcLifecycle.closing = false
	ipcLifecycle.mu.Unlock()
	t.Cleanup(func() {
		ipcLifecycle.mu.Lock()
		ipcLifecycle.server = previousServer
		ipcLifecycle.startState = previousStartState
		ipcLifecycle.closing = previousClosing
		ipcLifecycle.mu.Unlock()
	})

	err := StartIPCServer(nil, nil)
	if !errors.Is(err, errIPCLifecycleBusy) {
		t.Fatalf("StartIPCServer() error = %v, want %v", err, errIPCLifecycleBusy)
	}
}

// withCleanIPCLifecycle isolates a test from whatever the package-level
// lifecycle currently holds, and restores it afterwards.
func withCleanIPCLifecycle(t *testing.T) {
	t.Helper()
	ipcLifecycle.mu.Lock()
	// Field by field: ipcLifecycleState holds a mutex, so copying the struct
	// would copy the lock with it.
	prevServer, prevBackend := ipcLifecycle.server, ipcLifecycle.backend
	prevBootstrapped := ipcLifecycle.bootstrapped
	prevStartState, prevClosing := ipcLifecycle.startState, ipcLifecycle.closing
	prevGeneration := ipcLifecycle.generation
	// publishIPCResources also writes ipcClient, so it has to be restored too
	// or a later test reads a client this one left behind.
	prevClient := ipcClient.Load()
	ipcLifecycle.server = nil
	ipcLifecycle.backend = nil
	ipcLifecycle.bootstrapped = nil
	ipcLifecycle.mu.Unlock()
	t.Cleanup(func() {
		ipcLifecycle.mu.Lock()
		ipcLifecycle.server, ipcLifecycle.backend = prevServer, prevBackend
		ipcLifecycle.bootstrapped = prevBootstrapped
		ipcLifecycle.startState, ipcLifecycle.closing = prevStartState, prevClosing
		ipcLifecycle.generation = prevGeneration
		ipcLifecycle.mu.Unlock()
		ipcClient.Store(prevClient)
	})
}

// stubBootstrap swaps the detached LocalBackend.Start for one the test drives.
// The returned channel receives once per launch.
func stubBootstrap(t *testing.T, done <-chan struct{}) <-chan struct{} {
	t.Helper()
	launched := make(chan struct{}, 4)
	orig := bootstrapBackend
	bootstrapBackend = func(*backend.LocalBackend) <-chan struct{} {
		launched <- struct{}{}
		return done
	}
	t.Cleanup(func() { bootstrapBackend = orig })
	return launched
}

// A startup that lost its race is torn down immediately, so it must never have
// launched a bootstrap: Start would then be running against a backend that
// close is already tearing down, and LocalBackend.Close's peerWG.Wait cannot
// see a peerWG.Add that has not happened yet.
func TestPublishIPCResourcesCancelledStartupLaunchesNoBootstrap(t *testing.T) {
	withCleanIPCLifecycle(t)
	launched := stubBootstrap(t, nil)

	ipcLifecycle.mu.Lock()
	generation := ipcLifecycle.generation
	ipcLifecycle.generation++ // CloseIPCServer ran during setup
	ipcLifecycle.mu.Unlock()

	err := publishIPCResources(generation, ipcResources{})
	if !errors.Is(err, errIPCStartCanceled) {
		t.Fatalf("publishIPCResources() error = %v, want %v", err, errIPCStartCanceled)
	}
	if len(launched) != 0 {
		t.Errorf("launched %d bootstraps for a cancelled startup; want 0", len(launched))
	}
}

// The published path is the only one that starts a bootstrap, and it has to
// keep the handle so teardown can wait on it.
func TestPublishIPCResourcesLaunchesBootstrapAndKeepsHandle(t *testing.T) {
	withCleanIPCLifecycle(t)
	done := make(chan struct{})
	close(done)
	launched := stubBootstrap(t, done)

	ipcLifecycle.mu.Lock()
	generation := ipcLifecycle.generation
	ipcLifecycle.mu.Unlock()

	if err := publishIPCResources(generation, ipcResources{}); err != nil {
		t.Fatalf("publishIPCResources() error = %v", err)
	}
	if len(launched) != 1 {
		t.Errorf("launched %d bootstraps; want exactly 1", len(launched))
	}

	ipcLifecycle.mu.Lock()
	held := ipcLifecycle.bootstrapped
	ipcLifecycle.mu.Unlock()
	if held == nil {
		t.Error("lifecycle did not keep the bootstrap handle; teardown could not wait on it")
	}
}

// close must not tear the backend down while Start is still running. The wait
// is unbounded on purpose — see the comment on ipcResources.close.
func TestIPCResourcesCloseWaitsForBootstrap(t *testing.T) {
	t.Run("waits for a live bootstrap", func(t *testing.T) {
		bootstrapped := make(chan struct{})
		closed := make(chan struct{})
		go func() {
			defer close(closed)
			ipcResources{bootstrapped: bootstrapped}.close()
		}()

		select {
		case <-closed:
			t.Fatal("close returned while the bootstrap was still running")
		case <-time.After(100 * time.Millisecond):
		}

		close(bootstrapped)
		select {
		case <-closed:
		case <-time.After(5 * time.Second):
			t.Fatal("close did not return after the bootstrap finished")
		}
	})

	t.Run("does not wait when no bootstrap was launched", func(t *testing.T) {
		done := make(chan struct{})
		go func() {
			defer close(done)
			ipcResources{}.close()
		}()
		select {
		case <-done:
		case <-time.After(5 * time.Second):
			t.Fatal("close blocked with no bootstrap to wait for")
		}
	})
}

func TestIsTagAvailableUsesExtensionClientWithoutCore(t *testing.T) {
	prevCore := lanternCore.Load()
	lanternCore = atomic.Value{}
	want := &ipc.Client{}
	prevClient := ipcClient.Swap(want)
	prevLookup := serverByTag
	t.Cleanup(func() {
		if prevCore != nil {
			lanternCore.Store(prevCore)
		}
		ipcClient.Store(prevClient)
		serverByTag = prevLookup
	})

	var asked []string
	serverByTag = func(_ context.Context, c *ipc.Client, tag string) (bool, error) {
		if c != want {
			t.Fatalf("lookup used client %p, want the extension's %p", c, want)
		}
		asked = append(asked, tag)
		return tag == "present", nil
	}

	if IsTagAvailable("personal-proxies") {
		t.Fatal("IsTagAvailable = true for a missing tag; want the real answer")
	}
	if !IsTagAvailable("present") {
		t.Fatal("IsTagAvailable = false for a present tag")
	}
	if len(asked) != 2 {
		t.Fatalf("lookups = %d, want 2", len(asked))
	}
}

func TestIsTagAvailableFailsOpenWithoutAnyClient(t *testing.T) {
	prevCore := lanternCore.Load()
	lanternCore = atomic.Value{}
	prevClient := ipcClient.Swap(nil)
	t.Cleanup(func() {
		if prevCore != nil {
			lanternCore.Store(prevCore)
		}
		ipcClient.Store(prevClient)
	})
	if !IsTagAvailable("personal-proxies") {
		t.Fatal("IsTagAvailable = false with no backend; want fail-open true")
	}
}

func TestFindConnectionOwnerDelegatesAndSanitizesErrors(t *testing.T) {
	prev := findConnectionOwner
	t.Cleanup(func() {
		findConnectionOwner = prev
	})

	want := &libbox.ConnectionOwner{
		UserId:      501,
		UserName:    "tester",
		ProcessPath: "/Applications/DingTalk.app/Contents/MacOS/DingTalk",
	}
	findConnectionOwner = func(
		ipProtocol int32,
		sourceAddress string,
		sourcePort int32,
		destinationAddress string,
		destinationPort int32,
	) (*libbox.ConnectionOwner, error) {
		if ipProtocol != 6 || sourceAddress != "10.10.1.1" || sourcePort != 54321 ||
			destinationAddress != "1.1.1.1" || destinationPort != 443 {
			t.Fatalf(
				"unexpected args: proto=%d src=%s:%d dst=%s:%d",
				ipProtocol, sourceAddress, sourcePort, destinationAddress, destinationPort,
			)
		}
		return want, nil
	}

	got, err := FindConnectionOwner(6, "10.10.1.1", 54321, "1.1.1.1", 443)
	if err != nil {
		t.Fatalf("FindConnectionOwner() error = %v", err)
	}
	if got != want {
		t.Fatalf("FindConnectionOwner() = %+v, want %+v", got, want)
	}

	rawErr := errors.New("bad utf8: \xff\xfe")
	findConnectionOwner = func(int32, string, int32, string, int32) (*libbox.ConnectionOwner, error) {
		return nil, rawErr
	}

	_, err = FindConnectionOwner(6, "10.10.1.1", 54321, "1.1.1.1", 443)
	if !errors.Is(err, rawErr) {
		t.Fatalf("FindConnectionOwner() error = %v, want errors.Is(_, rawErr)", err)
	}
	if !utf8.ValidString(err.Error()) {
		t.Fatalf("FindConnectionOwner() error message is not valid UTF-8: %q", err.Error())
	}
}
