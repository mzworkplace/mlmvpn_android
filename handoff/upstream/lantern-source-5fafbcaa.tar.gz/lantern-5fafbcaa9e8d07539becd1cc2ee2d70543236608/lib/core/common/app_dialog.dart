import 'dart:io';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:lantern/core/common/common.dart';

class AppDialog {
  /// How long a button's callback waits after the dialog closes.
  static const actionDelay = Duration(milliseconds: 400);

  static Future<void> show({
    required BuildContext context,
    Widget? header,
    String? title,
    String? body,
    Widget? content,
    required String primaryLabel,
    OnPressed? onPrimaryPressed,
    String? secondaryLabel,
    String? secondaryIcon,
    OnPressed? onSecondaryPressed,
    bool centered = false,
    // Centers just the title while the body stays start-aligned (the
    // browser-warning layout: centered icon + title, left-aligned body).
    bool centeredTitle = false,
    bool barrierDismissible = false,
    bool scrollable = false,
    bool dismissOnSecondary = true,
    // When false the primary callback is responsible for dismissing the
    // dialog itself (e.g. vpnConflictDialog callers already pop).
    bool dismissOnPrimary = true,
    // Overrides dialogTheme's bg.elevated.
    Color? backgroundColor,
  }) {
    return showDialog<void>(
      context: context,
      barrierDismissible: barrierDismissible,
      builder: (context) {
        focusFirstOnTv(context);
        final textTheme = Theme.of(context).textTheme;
        return AlertDialog(
          scrollable: scrollable,
          // backgroundColor (unless given) and shape come from dialogTheme
          // in app_theme.dart
          backgroundColor: backgroundColor,
          contentPadding: EdgeInsets.all(24),
          // Buttons live inside content (not `actions`) so they can stretch
          // full-width and stack vertically per the design.
          content: SizedBox(
            // AlertDialog sizes to the content's intrinsic width, which
            // collapses custom content. maxFinite makes it fill instead; the
            // min/max width bounds come from dialogTheme (Material 280–560dp).
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: centered
                  ? CrossAxisAlignment.center
                  : CrossAxisAlignment.stretch,
              children: <Widget>[
                if (header != null) ...[header, SizedBox(height: size24)],
                if (title != null) ...[
                  Text(
                    title,
                    style: textTheme.headlineMedium,
                    textAlign: (centered || centeredTitle)
                        ? TextAlign.center
                        : TextAlign.start,
                  ),
                  SizedBox(height: 8),
                ],
                if (body != null)
                  Text(
                    body,
                    style: textTheme.bodyMedium?.copyWith(
                      color: context.textSecondary,
                      height: 23 / 16,
                    ),
                    textAlign: centered ? TextAlign.center : TextAlign.start,
                  ),
                ?content,
                SizedBox(height: size24),
                PrimaryButton(
                  label: primaryLabel,
                  onPressed: () {
                    if (!dismissOnPrimary) {
                      onPrimaryPressed?.call();
                      return;
                    }
                    // Pop via the dialog's own navigator so this also works
                    // when shown outside appRouter (e.g. widget tests).
                    Navigator.of(context).pop();
                    if (onPrimaryPressed != null) {
                      Future.delayed(actionDelay, onPrimaryPressed);
                    }
                  },
                ),
                if (secondaryLabel != null) ...[
                  SizedBox(height: 12),
                  SecondaryButton(
                    label: secondaryLabel,
                    icon: secondaryIcon,
                    useThemeColor: true,
                    onPressed: () {
                      if (!dismissOnSecondary) {
                        onSecondaryPressed?.call();
                        return;
                      }
                      Navigator.of(context).pop();
                      if (onSecondaryPressed != null) {
                        Future.delayed(actionDelay, onSecondaryPressed);
                      }
                    },
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  static void showLanternProDialog({
    required BuildContext context,
    String? label,
    OnPressed? onPressed,
  }) {
    final textTheme = Theme.of(context).textTheme;
    final size = MediaQuery.sizeOf(context);
    show(
      context: context,
      centered: true,
      header: LanternRoundedLogo(height: 45),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          SizedBox(
            width: size.width * 0.7,
            height: 40,
            child: AutoSizeText(
              'welcome_to_lantern_pro'.i18n,
              style: textTheme.headlineMedium,
              maxLines: 1,
              minFontSize: 20,
              maxFontSize: 24,
              textAlign: TextAlign.center,
            ),
          ),
          SizedBox(height: defaultSize),
          Text(
            'lantern_pro_description'.i18n,
            style: textTheme.bodyMedium?.copyWith(height: 23 / 16),
          ),
        ],
      ),
      primaryLabel: label ?? 'continue'.i18n,
      onPrimaryPressed: onPressed,
    );
  }

  static void purchaseRestoredDialog({
    required BuildContext context,
    OnPressed? onPressed,
  }) {
    show(
      context: context,
      header: Center(
        child: AppImage(
          path: AppImagePaths.greenCheck,
          height: 50,
          useThemeColor: false,
        ),
      ),
      title: 'purchase_restored_title'.i18n,
      body: 'purchase_restored_description'.i18n,
      primaryLabel: 'continue'.i18n,
      onPrimaryPressed: onPressed,
    );
  }

  static void noPurchaseFoundDialog({
    required BuildContext context,
    OnPressed? onPressed,
  }) {
    final body = Platform.isIOS
        ? 'no_purchase_found_body_ios'.i18n
        : 'no_purchase_found_body_android'.i18n;
    show(
      context: context,
      header: Center(child: AppImage(path: AppImagePaths.info, height: 40)),
      title: 'no_purchase_found_title'.i18n,
      body: body,
      primaryLabel: 'ok'.i18n,
      onPrimaryPressed: onPressed,
    );
  }

  /// Tells pre-v10 users device link codes are gone; set a password instead.
  static Future<void> deviceLinkingReplacedDialog({
    required BuildContext context,
    required VoidCallback onAddPassword,
    required VoidCallback onSignIn,
  }) {
    return show(
      context: context,
      header: Center(child: AppImage(path: AppImagePaths.info, height: 40)),
      centeredTitle: true,
      barrierDismissible: true,
      scrollable: true,
      title: 'device_linking_replaced_title'.i18n,
      body:
          '${'device_linking_replaced_body'.i18n}\n\n${'device_linking_replaced_body_two'.i18n}',
      primaryLabel: 'add_an_account_password'.i18n,
      onPrimaryPressed: onAddPassword,
      secondaryLabel: 'have_a_password_sign_in'.i18n,
      onSecondaryPressed: onSignIn,
    );
  }

  static Future<void> customDialog({
    required BuildContext context,
    required Widget content,
    required List<Widget> action,
    EdgeInsetsGeometry? actionPadding,
    bool barrierDismissible = false,
  }) {
    return showDialog<void>(
      context: context,
      barrierDismissible: barrierDismissible,
      builder: (context) {
        focusFirstOnTv(context);
        return AlertDialog(
          // backgroundColor and shape come from dialogTheme in app_theme.dart
          // Callers add their own top spacing inside content.
          contentPadding: EdgeInsets.symmetric(horizontal: size24),
          actionsPadding: actionPadding ?? EdgeInsets.all(size24),
          // AlertDialog sizes to the content's intrinsic width, which collapses
          // this custom content. maxFinite makes it fill instead; the min/max
          // width bounds come from dialogTheme (Material 280–560dp).
          content: SizedBox(width: double.maxFinite, child: content),
          // Actions stack vertically full-width per the design instead of the
          // default trailing OverflowBar row.
          actions: [
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var i = 0; i < action.length; i++) ...[
                  if (i > 0) SizedBox(height: 12),
                  action[i],
                ],
              ],
            ),
          ],
        );
      },
    );
  }

  static void errorDialog({
    required BuildContext context,
    required String title,
    required String content,
    String? action,
  }) {
    show(
      context: context,
      title: title,
      body: content,
      primaryLabel: action ?? 'ok'.i18n,
    );
  }

  /// Completes when the dialog closes.
  static Future<void> vpnConflictDialog({
    required BuildContext context,
    required VoidCallback onConnectAnyway,
  }) {
    appLogger.info('Showing VPN conflict dialog');
    return show(
      context: context,
      title: 'vpn_conflict_title'.i18n,
      body: 'vpn_conflict_body'.i18n,
      primaryLabel: 'vpn_conflict_connect_anyway'.i18n,
      onPrimaryPressed: () {
        appLogger.info('VPN conflict dialog: user chose connect anyway');
        onConnectAnyway();
      },
      // Callers pop the dialog inside onConnectAnyway themselves.
      dismissOnPrimary: false,
      secondaryLabel: 'vpn_conflict_dismiss'.i18n,
      onSecondaryPressed: () {
        appLogger.info('VPN conflict dialog: user dismissed');
      },
    );
  }

  /// Warns that diagnostic logs are shared unencrypted and may contain
  /// account data. Resolves true only when the user chooses to share.
  static Future<bool> shareLogsWarningDialog({
    required BuildContext context,
  }) async {
    var confirmed = false;
    await show(
      context: context,
      header: Center(child: AppImage(path: AppImagePaths.warning, height: 45)),
      centeredTitle: true,
      title: 'share_logs_warning_title'.i18n,
      body: 'share_logs_warning_body'.i18n,
      primaryLabel: 'share_logs_anyway'.i18n,
      dismissOnPrimary: false,
      onPrimaryPressed: () {
        confirmed = true;
        Navigator.of(context, rootNavigator: true).pop();
      },
      secondaryLabel: 'cancel'.i18n,
    );
    return confirmed;
  }

  /// Warns before pinning a server whose probes keep failing. Resolves true
  /// only when the user chooses to connect anyway.
  static Future<bool> unreachableServerDialog({
    required BuildContext context,
    required String location,
  }) async {
    var confirmed = false;
    // The caller's context can be disposed while the dialog is open.
    final navigator = Navigator.of(context, rootNavigator: true);
    await show(
      context: context,
      header: Center(child: AppImage(path: AppImagePaths.warning, height: 45)),
      centeredTitle: true,
      scrollable: true,
      title: 'unreachable_server_title'.i18n,
      body: 'unreachable_server_body'.i18n.fill([location]),
      primaryLabel: 'unreachable_server_connect_anyway'.i18n,
      dismissOnPrimary: false,
      onPrimaryPressed: () {
        confirmed = true;
        navigator.pop();
      },
      secondaryLabel: 'cancel'.i18n,
    );
    return confirmed;
  }

  static void dialog({
    required BuildContext context,
    required String title,
    required String content,
    String? action,
    OnPressed? onPressed,
  }) {
    show(
      context: context,
      title: title,
      body: content,
      primaryLabel: action ?? 'ok'.i18n,
      onPrimaryPressed: onPressed,
      // Preserve the original dialog contract: when a callback is supplied,
      // it is responsible for dismissing or replacing the current route.
      dismissOnPrimary: onPressed == null,
    );
  }
}
