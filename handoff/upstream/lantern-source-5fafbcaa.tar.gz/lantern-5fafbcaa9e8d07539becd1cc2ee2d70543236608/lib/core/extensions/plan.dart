import 'package:intl/intl.dart';
import 'package:lantern/core/common/common.dart';
import 'package:lantern/core/models/plan_data.dart';
import 'package:lantern/core/models/user.dart';
import 'package:lantern/core/services/app_purchase.dart';
import 'package:lantern/core/services/injection_container.dart' show sl;
import 'package:lantern/core/utils/currency_utils.dart';

final _ddmmyyFormatter = DateFormat('dd/MM/yy');
final _mmddyyFormatter = DateFormat('MM/dd/yy');

extension PlanExtension on Plan {
  String get formattedYearlyPrice => _formatPriceMap(price);

  String get formattedMonthlyPrice => _formatPriceMap(expectedMonthlyPrice);

  /// Price shown on the plan card: the store's localized price (what it will
  /// actually charge) on store builds, the API price otherwise/as fallback.
  String get displayPrice => _storePrice?.formatted ?? formattedYearlyPrice;

  /// Per-month line under [displayPrice]: the store price spread over the
  /// months it covers on store builds, the API's expected monthly price
  /// otherwise. Empty when the store charge has no per-month equivalent.
  String get displayMonthlyPrice {
    final price = _storePrice;
    if (price == null) return formattedMonthlyPrice;
    final monthly = price.monthly;
    if (monthly == null) return '';
    return CurrencyUtils.formatCurrency(monthly * 100, price.currencyCode);
  }

  StorePrice? get _storePrice =>
      isStoreVersion() ? sl<AppPurchase>().storePriceFor(id) : null;

  /// The pre-discount yearly price shown struck through next to the
  /// discounted one. On store builds it is the base SKU's store price, so it
  /// matches the charge price's currency; otherwise the backend's
  /// `originalPrice`. Empty when nothing is discounted.
  String get formatOriginalPrice {
    final store = _storePrice;
    if (store != null) {
      return store.regular == store.formatted ? '' : store.regular;
    }
    return _formatPriceMap(originalPrice);
  }

  /// The amount deducted by the affiliate discount: original − discounted
  /// yearly price, both taken directly from the backend (no percentage math).
  /// Shown as the "Promo Code" deduction at checkout. Empty when the backend
  /// didn't supply an original price.
  String get formatDiscountAmount {
    final original = originalPrice;
    if (original == null || original.isEmpty) return '';
    final deducted = _amountOf(original) - _amountOf(price);
    return CurrencyUtils.formatCurrency(deducted, price.keys.first);
  }

  /// Formats the first `<currency>: amount` entry of [prices] as currency;
  /// returns '' when [prices] is null or empty.
  String _formatPriceMap(Map<String, dynamic>? prices) {
    if (prices == null || prices.isEmpty) return '';
    return CurrencyUtils.formatCurrency(_amountOf(prices), prices.keys.first);
  }

  double _amountOf(Map<String, dynamic> prices) =>
      double.parse(prices.values.first.toString());

  /// "Billed every year. Cancel anytime." for a subscription, localized.
  String get autoRenewNotice => switch (id.split('-').first) {
    '1m' => 'billed_monthly_cancel_anytime'.i18n,
    '1y' => 'billed_yearly_cancel_anytime'.i18n,
    '2y' => 'billed_every_two_years_cancel_anytime'.i18n,
    _ => 'renews_automatically_cancel_anytime'.i18n,
  };
}

extension IsoDateFormatter on UserDataModel {
  String toDate() {
    try {
      if (isExpired) {
        if (lastExpiredOn <= 0) {
          return "N/A";
        }
        final expirationDate = DateTime.fromMillisecondsSinceEpoch(
          lastExpiredOn * 1000,
          isUtc: true,
        ).toLocal();
        final formattedDate = _formatDate(expirationDate);
        return "$formattedDate  ${'expired'.i18n}";
      }

      final autoRenew = subscriptionData.autoRenew;
      final endAt = subscriptionData.endAt;
      // Validate expiration exists
      if (expiration <= 0) {
        return "N/A";
      }
      if (autoRenew && endAt != 0) {
        // Active subscription case
        if (endAt <= 0) {
          return "N/A";
        }
        final dateTime = DateTime.fromMillisecondsSinceEpoch(
          endAt * 1000,
          isUtc: true,
        ).toLocal();

        return _formatDate(dateTime);
      }
      // Non-subscription plan case
      final expirationDate = DateTime.fromMillisecondsSinceEpoch(
        expiration * 1000,
        isUtc: true,
      ).toLocal();
      final formattedDate = _formatDate(expirationDate);
      if (expirationDate.isBefore(DateTime.now())) {
        return "$formattedDate  ${'expired'.i18n}";
      }
      return formattedDate;
    } catch (e) {
      return "N/A";
    }
  }

  /// Formatted account expiration when it extends past the subscription's
  /// endAt (e.g. stacked or support-granted time). Null when there is no
  /// extra time to show.
  String? get extendedExpirationDate {
    try {
      if (isExpired) return null;
      final endAt = subscriptionData.endAt;
      if (!subscriptionData.autoRenew || endAt <= 0) return null;
      if (expiration <= endAt) return null;
      final expirationDate = DateTime.fromMillisecondsSinceEpoch(
        expiration * 1000,
        isUtc: true,
      ).toLocal();
      return _formatDate(expirationDate);
    } catch (e) {
      return null;
    }
  }

  String _formatDate(DateTime dateTime) =>
      AppDateFormats.dayMonthYearOrdinal(dateTime);
}
