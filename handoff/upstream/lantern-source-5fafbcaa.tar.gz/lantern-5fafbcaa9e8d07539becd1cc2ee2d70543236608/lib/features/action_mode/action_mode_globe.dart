import 'dart:async';
import 'dart:math' show max, min;

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_earth_globe/flutter_earth_globe.dart';
import 'package:flutter_earth_globe/flutter_earth_globe_controller.dart';
import 'package:flutter_earth_globe/globe_coordinates.dart';
import 'package:flutter_earth_globe/point.dart';
import 'package:flutter_earth_globe/point_connection.dart';
import 'package:flutter_earth_globe/point_connection_style.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:lantern/core/common/common.dart';
import 'package:lantern/core/models/action_mode_connection_event.dart';
import 'package:lantern/core/services/geo_lookup_service.dart';
import 'package:lantern/features/action_mode/provider/share_notifier.dart';
import 'package:lantern/features/action_mode/provider/action_mode_tab_visible_notifier.dart';

/// Globe drawing an arc from each connected peer's country to the user's own
/// location, fed by ShareNotifier.connectionEvents.
class ActionModeGlobe extends ConsumerStatefulWidget {
  const ActionModeGlobe({super.key});

  @override
  ConsumerState<ActionModeGlobe> createState() => _ActionModeGlobeState();
}

class _ActionModeGlobeState extends ConsumerState<ActionModeGlobe>
    with AutomaticKeepAliveClientMixin {
  // TabBarView disposes off-screen pages; keep the globe resident so a tab
  // switch doesn't redo the origin lookup, texture load, and arc replay.
  @override
  bool get wantKeepAlive => true;

  // The spec's arcs are a cyan-to-yellow gradient; the package only supports
  // flat colours, so alternate the two ends by workerIdx.
  static final _arcColors = [
    AppColors.blue4.withValues(alpha: 0.75),
    AppColors.yellow3.withValues(alpha: 0.75),
  ];
  static final _originPointColor = AppColors.blue4.withValues(alpha: 0.15);
  static const _peerPointColor = AppColors.green6;
  static const _atmosphereDark = AppColors.blue4;
  static const _atmosphereLight = AppColors.blue6;
  // Brief connections (URL-test probes) keep their arc long enough to be seen.
  static const _arcLinger = Duration(seconds: 5);

  final FlutterEarthGlobeController _globeController =
      FlutterEarthGlobeController(
        isRotating: PlatformUtils.isDesktop,
        rotationSpeed: 0.02,
        zoom: 0,
        isZoomEnabled: false,
        showAtmosphere: true,
        atmosphereColor: _atmosphereDark,
        atmosphereOpacity: 0.18,
        atmosphereBlur: 22,
        // Mostly ambient so the light texture doesn't render as a grey ball.
        ambientLight: 0.97,
        lightIntensity: 0.15,
      );

  StreamSubscription<ActionModeConnectionEvent>? _eventSub;
  GlobeCoordinates? _originCoords;
  final Map<int, Timer> _pendingRemovals = {};
  // Everything on the globe, so a stop can clear it without -1 events.
  final Set<int> _drawn = {};
  Brightness? _appliedBrightness;

  @override
  void initState() {
    super.initState();
    // Subscribe before the origin lookup so nothing is missed; _addPeer skips
    // draws until origin is known and _initOrigin replays them.
    _eventSub = ref
        .read(shareProvider.notifier)
        .connectionEvents
        .listen(_handleEvent);
    _initOrigin();
  }

  @override
  void dispose() {
    _eventSub?.cancel();
    for (final t in _pendingRemovals.values) {
      t.cancel();
    }
    _pendingRemovals.clear();
    // The globe widget disposes the controller's animation itself.
    super.dispose();
  }

  // Theme must be read where a dependency is registered; macOS can change
  // platformBrightness after the first frame.
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final brightness = Theme.of(context).brightness;
    if (brightness == _appliedBrightness) return;
    _appliedBrightness = brightness;
    // Controller setters notify synchronously; defer past the build phase.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _applyTheme(brightness);
    });
  }

  void _applyTheme(Brightness brightness) {
    final isDark = brightness == Brightness.dark;
    _globeController.loadSurface(
      AssetImage(
        isDark
            ? 'assets/unbounded/uv-map-dark.png'
            : 'assets/unbounded/uv-map.png',
      ),
    );
    _globeController.atmosphereColor = isDark
        ? _atmosphereDark
        : _atmosphereLight;
  }

  Future<void> _initOrigin() async {
    final coords = await GeoLookupService.selfLookup();
    if (!mounted) return;
    _originCoords = coords;
    _globeController.addPoint(
      Point(
        id: 'origin',
        coordinates: coords,
        style: PointStyle(color: _originPointColor, size: 8),
      ),
    );
    _globeController.focusOnCoordinates(coords, animate: false);
    ref.read(shareProvider.notifier).replayCurrentPeers();
  }

  void _handleEvent(ActionModeConnectionEvent event) {
    if (event.state == 1 && event.coordinates != null) {
      _pendingRemovals.remove(event.workerIdx)?.cancel();
      _addPeer(event);
    } else if (event.state == -1) {
      _pendingRemovals[event.workerIdx]?.cancel();
      _pendingRemovals[event.workerIdx] = Timer(_arcLinger, () {
        _pendingRemovals.remove(event.workerIdx);
        if (!mounted) return;
        _removePeer(event.workerIdx);
      });
    }
  }

  // Deterministic per-peer offset so same-country arcs don't overlap.
  GlobeCoordinates _jittered(GlobeCoordinates base, int widx) {
    final hash = widx * 2654435761; // Knuth multiplicative hash
    final dLat = ((hash >> 4) & 0xff) / 255.0 * 4.0 - 2.0; // [-2, +2]°
    final dLng = ((hash >> 12) & 0xff) / 255.0 * 4.0 - 2.0;
    return GlobeCoordinates(base.latitude + dLat, base.longitude + dLng);
  }

  void _addPeer(ActionModeConnectionEvent event) {
    if (!mounted || _originCoords == null) return;
    final coords = _jittered(event.coordinates!, event.workerIdx);
    // dashAnimateTime stays 0: any other value keeps the package's repaint
    // loop running for as long as an arc exists.
    _globeController.addPointConnection(
      PointConnection(
        id: 'conn_${event.workerIdx}',
        start: coords,
        end: _originCoords!,
        curveScale: .6,
        style: PointConnectionStyle(
          color: _arcColors[event.workerIdx.abs() % _arcColors.length],
          lineWidth: 3,
          type: PointConnectionType.solid,
          dashAnimateTime: 0,
          animateOnAdd: !event.isReplay,
        ),
      ),
    );
    _globeController.addPoint(
      Point(
        id: 'peer_${event.workerIdx}',
        coordinates: coords,
        style: PointStyle(color: _peerPointColor, size: 6),
      ),
    );
    _drawn.add(event.workerIdx);
    // Replays seed a freshly mounted globe and should not move the camera.
    if (event.isReplay) return;
    _globeController.focusOnCoordinates(
      coords,
      animate: true,
      duration: const Duration(milliseconds: 900),
      curve: Curves.easeInOutCubic,
    );
  }

  void _removePeer(int workerIdx) {
    _globeController.removePointConnection('conn_$workerIdx');
    _globeController.removePoint('peer_$workerIdx');
    _drawn.remove(workerIdx);
  }

  void _clearAllPeers() {
    for (final t in _pendingRemovals.values) {
      t.cancel();
    }
    _pendingRemovals.clear();
    for (final workerIdx in _drawn.toList()) {
      _removePeer(workerIdx);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    // TickerMode freezes the spin and any in-flight turn while the tab is
    // off screen.
    final visible = ref.watch(actionModeTabVisibleProvider);
    // Stopping tears down the event stream without -1 events.
    ref.listen(shareProvider.select((s) => s.active), (prev, next) {
      if (prev == true && next == false) _clearAllPeers();
    });
    return TickerMode(
      enabled: visible,
      child: LayoutBuilder(
        builder: (context, constraints) {
          // The package positions the sphere relative to MediaQuery.size, so
          // override it with this slot's size to keep the sphere centred.
          final widgetSize = Size(constraints.maxWidth, constraints.maxHeight);
          // Room kept above the sphere for its glow, which the scroll view
          // would otherwise cut at its top edge, and below it for the status
          // pill, which sits at the slot's bottom.
          const glowRoom = 40.0;
          const pillRoom = 52.0;
          final width = constraints.maxWidth;
          final height = constraints.maxHeight;
          // ~66% of the slot's width, clamped by height so the sphere fits
          // between the glow room and the pill. A short slot, which scrolls
          // anyway, keeps a sphere worth seeing and lets the pill overlap it.
          final free = height - glowRoom - pillRoom;
          final radius = min(
            width * 0.33,
            max(0.0, max(free / 2, (height - glowRoom) * 0.3)),
          );
          // The sphere's centre: a little above the slot's middle, kept clear
          // of the glow room first and of the pill where there is room.
          final highest = glowRoom + radius;
          final lowest = height - pillRoom - radius;
          final centre = lowest >= highest
              ? (height * 0.45).clamp(highest, lowest)
              : highest;
          // The package offsets the sphere from the slot's centre by this
          // share of the slot's half height.
          final alignment = Alignment(
            0,
            height > 0
                ? ((centre - height / 2) / (height / 2)).clamp(-1.0, 1.0)
                : 0,
          );
          return Stack(
            // The glow reaches past the slot's sides on a narrow window.
            clipBehavior: Clip.none,
            children: [
              // Shadow sits outside the ClipRect below, which would crop its
              // blur.
              Positioned(
                top: centre - radius,
                left: width / 2 - radius,
                child: Container(
                  width: radius * 2,
                  height: radius * 2,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x21006163),
                        offset: Offset(0, 4),
                        blurRadius: 64,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                width: constraints.maxWidth,
                height: constraints.maxHeight,
                // Keeps high-curving arcs inside the slot.
                child: ClipRect(
                  child: MediaQuery(
                    data: MediaQuery.of(context).copyWith(
                      size: widgetSize,
                      // Match the parent drag thresholds so the deeper globe
                      // recognizer wins: scale gestures use twice touchSlop.
                      gestureSettings: DeviceGestureSettings(
                        touchSlop:
                            (MediaQuery.of(context).gestureSettings.touchSlop ??
                                kTouchSlop) /
                            2,
                      ),
                    ),
                    child: FlutterEarthGlobe(
                      controller: _globeController,
                      radius: radius,
                      alignment: alignment,
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
