import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:lantern/core/common/common.dart';
import 'package:lantern/core/utils/deeplink_utils.dart';
import 'package:lantern/core/widgets/app_rich_text.dart';
import 'package:lantern/core/widgets/info_row.dart';
import 'package:lantern/core/widgets/trust_dialog.dart';
import 'package:lantern/features/action_mode/provider/share_notifier.dart';
import 'package:lantern/features/helpers/approve_helper_dialog.dart'
    show spokenCode;
import 'package:lantern/features/helpers/helper_approved_dialog.dart';
import 'package:lantern/features/helpers/helper_errors.dart';
import 'package:lantern/features/helpers/helping_friends.dart'
    show HelperKeystoreResetNotice;
import 'package:lantern/features/helpers/invite_share.dart' show shareInvite;
import 'package:lantern/features/helpers/models/helpers_view.dart';
import 'package:lantern/features/helpers/provider/helpers_notifier.dart';
import 'package:lantern/features/home/provider/app_setting_notifier.dart';

/// "Become a Personal Proxy": a volunteer accepts an invite, from a link that
/// opened the app (filled in), a scanned QR code, or a pasted link. It shows
/// the code to read to the friend, then waits for approval. The link is a
/// secret: it is never logged.
@RoutePage(name: 'HelpFriend')
class HelpFriend extends HookConsumerWidget {
  const HelpFriend({super.key, this.fromLink = false, this.newInvite = false});

  /// Whether a deep link opened this screen. Its secret is held by the
  /// notifier (holdLink), never passed in route arguments.
  final bool fromLink;

  /// Opened to add another friend ("Paste another invite link"): show the
  /// paste form even while an earlier claim waits, rather than its code.
  final bool newInvite;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final textTheme = Theme.of(context).textTheme;
    final helpers = ref.watch(helpersProvider);
    // Held rather than read after an await: this screen may be gone by then.
    final notifier = ref.read(helpersProvider.notifier);
    final share = ref.read(shareProvider.notifier);
    final link = useMemoized(() => fromLink ? notifier.takeLink() : null);
    final linkCtl = useTextEditingController(text: link ?? '');
    final linkText = useValueListenable(linkCtl).text;
    final nameCtl = useTextEditingController(text: helpers.view.myName);
    final code = useState<String?>(null);
    // This screen's own claim: its outcome, not anyone else's, ends the wait.
    final claimId = useRef<String?>(null);
    // To tell which new pairing came from this claim.
    final helpingAtClaim = useRef<Set<String>>(const {});
    // The view when the claim was answered. A claim missing from that same
    // view (its refresh failed) has not left yet; it may not have arrived.
    final viewAtClaim = useRef<HelpersView?>(null);
    final claimSeen = useRef(false);
    // Once settled, the outcome stays: a pairing ended later does not turn
    // "approved" into "no longer pending".
    final settled = useRef<_ClaimOutcome?>(null);
    final error = useState<String?>(null);
    final busy = useState(false);
    final resumed = useRef(false);
    // The approval has been handed to its dialog, once.
    final finished = useRef(false);
    // Bumped to try the handoff again while a dialog covers this screen;
    // one retry is pending at a time, whatever else rebuilds meanwhile.
    final handoffRetry = useState(0);
    final retryPending = useRef(false);

    // While this screen submits, resumes or waits on its claim, its success
    // screen asks before Action Mode starts for the approval, rather than
    // Home starting it. Taken before the claim is sent: the claim's own
    // refresh can bring the approval before it answers. Released without
    // the success screen having asked, nothing starts.
    final holding = useRef(false);
    void holdApproval() {
      if (holding.value) return;
      holding.value = true;
      notifier.holdApprovalStart();
    }

    void releaseApproval() {
      if (!holding.value) return;
      holding.value = false;
      notifier.releaseApprovalStart();
    }

    useEffect(() => releaseApproval, const []);

    useEffect(() {
      // refreshIfUsed, not refresh: opening this screen must not touch the
      // keystore (Plan rules). The claim unlocks it.
      unawaited(notifier.refreshIfUsed());
      return null;
    }, const []);

    useEffect(() {
      // Opened without a link while a claim waits (the volunteer backed out
      // of the code): show that code again, once. A provisional claim may
      // never have reached the inviter, and is retried by claiming its link
      // again; an expired one waits for nothing.
      final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      final pending = helpers.view.waitingClaims(now);
      if (link != null ||
          newInvite ||
          resumed.value ||
          code.value != null ||
          busy.value ||
          pending.isEmpty) {
        return null;
      }
      resumed.value = true;
      holdApproval();
      final latest = pending.reduce(
        (a, b) => b.expiresUnix >= a.expiresUnix ? b : a,
      );
      claimId.value = latest.id;
      helpingAtClaim.value = {
        for (final p in helpers.view.helping) p.pairingId,
      };
      viewAtClaim.value = helpers.view;
      code.value = latest.code;
      return null;
    }, [helpers.view.claims]);

    useEffect(() {
      // Desktop only: on iOS and Android a programmatic read prompts or
      // toasts, so mobile reads wait for the Paste button. Anything that is
      // not an invite is dropped unseen.
      if (fromLink || code.value != null || !PlatformUtils.isDesktop) {
        return null;
      }
      unawaited(() async {
        final text = await _readClipboard();
        if (!context.mounted || linkCtl.text.isNotEmpty) return;
        if (isHelperInviteInput(text)) linkCtl.text = text.trim();
      }());
      return null;
    }, const []);

    if (!AppBuildInfo.enableHelperInvites) {
      return BaseScreen(
        title: 'become_personal_proxy'.i18n,
        body: Center(child: Text('helper_error_disabled'.i18n)),
      );
    }

    Future<void> submit() async {
      error.value = null;
      // Every invite accepted: the trust dialog first, whose Continue sends
      // the request.
      if (!await showHelpFriendTrustDialog(context, gate: true)) return;
      if (!context.mounted) return;
      busy.value = true;
      final consented = await share.ensureConsent(context);
      if (!context.mounted) return;
      if (!consented) {
        busy.value = false;
        return;
      }
      holdApproval();
      // Taken with the hold: a pairing that arrives while the claim is sent
      // may be this claim's.
      final helpingBefore = {
        for (final p in ref.read(helpersProvider).view.helping) p.pairingId,
      };
      final r = await notifier.claim(
        normalizeHelperInviteInput(linkCtl.text),
        nameCtl.text,
      );
      if (!context.mounted) return;
      busy.value = false;
      if (!r.ok) {
        releaseApproval();
        if (r.error == 'already_claimed') {
          // A dialog, not a state of this screen: Close returns to the form
          // with the link gone, since it is spent.
          await _showInviteUsedDialog(context);
          if (context.mounted) linkCtl.clear();
          return;
        }
        error.value = r.error;
        return;
      }
      final claimed = r.data['code'];
      if (claimed is! String || claimed.isEmpty) {
        releaseApproval();
        error.value = 'unavailable';
        return;
      }
      final now = ref.read(helpersProvider);
      claimId.value = r.data['claim_id'] as String?;
      helpingAtClaim.value = helpingBefore;
      viewAtClaim.value = now.view;
      code.value = claimed;
    }

    void setLink(String text) {
      linkCtl.text = text.trim();
      if (_linkErrors.contains(error.value)) error.value = null;
    }

    final outcome = code.value == null
        ? _ClaimOutcome.waiting
        : settled.value ??
              _claimOutcome(
                helpers.view,
                claimId.value,
                helpingAtClaim.value,
                seen:
                    claimSeen.value ||
                    !identical(helpers.view, viewAtClaim.value),
              );
    if (claimId.value != null &&
        helpers.view.claims.any((c) => c.id == claimId.value)) {
      claimSeen.value = true;
    }
    if (outcome != _ClaimOutcome.waiting) settled.value = outcome;
    final approved = outcome == _ClaimOutcome.approved;

    final Widget body;
    if (approved) {
      final route = ModalRoute.of(context);
      if (!finished.value && route != null && !route.isCurrent) {
        // A dialog covers this screen, such as the app-wide approval
        // prompt: pop would close that instead. Ask again shortly.
        if (!retryPending.value) {
          retryPending.value = true;
          Future<void>.delayed(const Duration(milliseconds: 250), () {
            retryPending.value = false;
            if (context.mounted) handoffRetry.value++;
          });
        }
      } else if (!finished.value) {
        finished.value = true;
        final name = _approvedName(
          helpers,
          claimId.value,
          helpingAtClaim.value,
        );
        // The hold passes to the dialog: Home must not start Action Mode
        // for this approval until the user has answered its checkbox. This
        // screen's own release (on dispose) is thereby disarmed.
        final held = holding.value;
        holding.value = false;
        // Shown on the root navigator after this screen is gone: the dialog
        // is "not a full screen", and pop would otherwise close the dialog.
        final rootNavigator = Navigator.of(context, rootNavigator: true);
        // The dialog outlives this screen, so it reads through the container.
        final container = ProviderScope.containerOf(context, listen: false);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          // Gone before the handoff: no dialog will ask, and the dispose
          // release was disarmed above, so let go here.
          if (!context.mounted) {
            if (held) notifier.releaseApprovalStart();
            return;
          }
          // A dialog pushed since the build, such as the app-wide approval
          // prompt: pop would close it undecided. Hand the hold back and
          // ask again.
          final now = ModalRoute.of(context);
          if (now != null && !now.isCurrent) {
            finished.value = false;
            holding.value = held;
            handoffRetry.value++;
            return;
          }
          // pop, not maybePop: this screen's own PopScope would veto it.
          appRouter.pop();
          unawaited(
            showHelperApprovedDialog(
              rootNavigator.context,
              name: name,
            ).whenComplete(() {
              if (!held) return;
              // Auto-enable already on: the box opened checked, so no
              // change of it started Action Mode for this friend. Start it
              // once the dialog closes, by Done or Back alike, as Home
              // would have without the hold: the box is the user's answer,
              // and only unchecking it says no.
              if (container.read(appSettingProvider).unboundedAutoEnable) {
                unawaited(
                  container
                      .read(shareProvider.notifier)
                      .startForHelper(ref, requireAutoEnable: true),
                );
              }
              notifier.releaseApprovalStart();
            }),
          );
        });
      }
      // The frame between the approval and the pop.
      return PopScope(
        canPop: false,
        child: BaseScreen(
          title: 'become_personal_proxy'.i18n,
          appBar: CustomAppBar(
            title: Text('become_personal_proxy'.i18n),
            leading: const SizedBox.shrink(),
          ),
          body: const SizedBox.shrink(),
        ),
      );
    } else if (outcome == _ClaimOutcome.gone) {
      body = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: defaultSize),
          Text(
            'help_friend_no_longer_pending'.i18n,
            key: const Key('help_friend.gone'),
            style: textTheme.titleLarge,
          ),
          const SizedBox(height: defaultSize),
          PrimaryButton(
            label: 'help_friend_done'.i18n,
            onPressed: () => appRouter.maybePop(),
          ),
        ],
      );
    } else if (code.value != null) {
      body = ListView(
        padding: EdgeInsets.zero,
        children: [
          AppCard(
            key: const Key('help_friend.waiting'),
            padding: const EdgeInsets.all(defaultSize),
            child: Column(
              children: [
                Text(
                  'help_friend_tell_code'.i18n,
                  textAlign: TextAlign.center,
                  style: textTheme.titleLarge,
                ),
                const SizedBox(height: 12),
                // Its own node: the card would merge it into one label.
                Semantics(
                  container: true,
                  label: spokenCode(code.value!),
                  excludeSemantics: true,
                  child: Text(
                    code.value!,
                    key: const Key('help_friend.code'),
                    textAlign: TextAlign.center,
                    style: textTheme.displayMedium?.copyWith(letterSpacing: 8),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'help_friend_code_check'.i18n,
                  textAlign: TextAlign.center,
                  style: textTheme.bodyMedium!.copyWith(
                    color: context.textSecondary,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        'help_friend_waiting_approval'.i18n,
                        style: textTheme.labelMedium!.copyWith(
                          color: context.textTertiary,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: defaultSize),
          // The app's note spec, as on Invite a Personal Proxy.
          InfoRow(
            key: const Key('help_friend.code_note'),
            backgroundColor: context.bgPromo,
            imagePath: AppImagePaths.warning,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            minTileHeight: 40,
            text: 'help_friend_code_note'.i18n,
            textStyle: textTheme.labelLarge!.copyWith(
              color: context.textSecondary,
            ),
          ),
        ],
      );
    } else if (error.value == 'already_helping') {
      final helping = helpers.view.helping;
      // The engine says only that this link is one this device helps for;
      // with a single pairing, that is the one.
      final text = helping.length == 1 && helping.single.name.isNotEmpty
          ? 'help_friend_already_helping_named'.i18n.fill([helping.single.name])
          : 'help_friend_already_helping'.i18n;
      body = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: defaultSize),
          Icon(
            Icons.check_circle_outline,
            size: 48,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 12),
          Text(
            text,
            key: const Key('help_friend.already_helping'),
            style: textTheme.titleLarge,
          ),
          const SizedBox(height: defaultSize),
          PrimaryButton(
            label: 'help_friend_done'.i18n,
            onPressed: () => appRouter.maybePop(),
          ),
        ],
      );
    } else {
      final linkValid = isHelperInviteInput(linkText);
      // A link that cannot be an invite, as typed, or as the engine refused.
      final String? linkError = _linkErrors.contains(error.value)
          ? helperErrorText(error.value!)
          : linkText.trim().isNotEmpty && !linkValid
          ? helperErrorText('bad_link')
          : null;
      final hintStyle = textTheme.labelMedium!.copyWith(
        color: context.textTertiary,
      );
      body = ListView(
        padding: EdgeInsets.zero,
        children: [
          // One line; the rest is behind Learn more, as on Invite a
          // Personal Proxy.
          InfoRow(
            key: const Key('help_friend.trust_warning'),
            backgroundColor: context.bgPromo,
            imagePath: AppImagePaths.warning,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            minTileHeight: 40,
            text: '',
            child: AppRichText(
              key: const Key('help_friend.learn_more'),
              texts: '${'help_friend_trust_warning'.i18n} ',
              boldTexts: 'invite_trust_learn_more'.i18n,
              boldUnderline: true,
              boldColor: context.textLink,
              boldOnPressed: () =>
                  unawaited(showHelpFriendTrustDialog(context)),
            ),
          ),
          const SizedBox(height: defaultSize),
          if (helpers.keystoreReset) ...[
            HelperKeystoreResetNotice(notifier: notifier),
            const SizedBox(height: defaultSize),
          ],
          AppCard(
            key: const Key('help_friend.form'),
            padding: const EdgeInsets.all(defaultSize),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'help_friend_form_title'.i18n,
                  style: textTheme.titleMedium,
                ),
                const SizedBox(height: defaultSize),
                AppTextField(
                  fieldKey: const Key('help_friend.link'),
                  controller: linkCtl,
                  label: 'help_friend_link_label'.i18n,
                  hintText: 'help_friend_paste'.i18n,
                  prefixIcon: Icons.link,
                  suffixIcon: IconButton(
                    key: const Key('help_friend.paste_button'),
                    tooltip: 'help_friend_paste_button'.i18n,
                    icon: const Icon(Icons.content_paste),
                    onPressed: () async {
                      final pasted = await _readClipboard();
                      if (!context.mounted || pasted.trim().isEmpty) return;
                      setLink(pasted);
                    },
                  ),
                  autocorrect: false,
                  enableSuggestions: false,
                  enableIMEPersonalizedLearning: false,
                  onChanged: (_) {
                    if (_linkErrors.contains(error.value)) error.value = null;
                  },
                  errorKey: const Key('help_friend.link_error'),
                  errorText: linkError,
                  // Invites start with the friend: one who wants help
                  // offered can be asked to send one.
                  helper: Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 4,
                    children: [
                      Text('help_friend_no_link_yet'.i18n),
                      Builder(
                        builder: (linkContext) => Semantics(
                          link: true,
                          child: InkWell(
                            key: const Key('help_friend.ask_invite'),
                            onTap: () => shareInvite(
                              linkContext,
                              'help_friend_ask_invite_message'.i18n,
                            ),
                            child: Text(
                              'help_friend_ask_send_link'.i18n,
                              style: hintStyle.copyWith(
                                color: context.textLink,
                                decoration: TextDecoration.underline,
                                decorationColor: context.textLink,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (AppBuildInfo.enableQrScanner && PlatformUtils.isMobile)
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: AppTextButton(
                      key: const Key('help_friend.scan'),
                      label: 'help_friend_scan'.i18n,
                      onPressed: () async {
                        final scanned = await appRouter.push(QrCodeScanner());
                        if (scanned is String && context.mounted) {
                          setLink(scanned);
                        }
                      },
                    ),
                  ),
                const SizedBox(height: defaultSize),
                AppTextField(
                  fieldKey: const Key('help_friend.name'),
                  controller: nameCtl,
                  label: 'help_friend_your_name_label'.i18n,
                  hintText: 'helpers_your_name_hint'.i18n,
                  prefixIcon: Icons.person_outline,
                  maxLength: 60,
                  textCapitalization: TextCapitalization.words,
                  helperText: 'help_friend_name_hint_server_list'.i18n,
                ),
                if (error.value != null && linkError == null) ...[
                  const SizedBox(height: 8),
                  Text(
                    helperErrorText(error.value!),
                    key: const Key('help_friend.error'),
                    style: textTheme.bodyMedium!.copyWith(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
                ],
                const SizedBox(height: defaultSize),
                KeyedSubtree(
                  key: const Key('help_friend.accept'),
                  child: PrimaryButton(
                    label: 'help_friend_become'.i18n,
                    enabled: !busy.value && linkValid,
                    onPressed: submit,
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }
    return BaseScreen(title: 'become_personal_proxy'.i18n, body: body);
  }
}

/// "Trust the person you help": the shared trust dialog with this screen's
/// text. As a [gate] (before the request is sent), with the "I understand
/// the risks" check and Continue; from Learn more, with Got It.
Future<bool> showHelpFriendTrustDialog(
  BuildContext context, {
  bool gate = false,
}) => showTrustDialog(
  context,
  key: const Key('help_friend.trust_dialog'),
  title: 'help_friend_trust_title'.i18n,
  paragraphs: [
    'help_friend_trust_message_one'.i18n,
    'help_friend_trust_message_two'.i18n,
    'help_friend_trust_message_three'.i18n,
  ],
  gate: gate,
);

/// The clipboard's text, or empty when it has none or cannot be read.
Future<String> _readClipboard() async {
  try {
    return (await Clipboard.getData(Clipboard.kTextPlain))?.text ?? '';
  } catch (_) {
    return '';
  }
}

/// Engine errors about the link itself, shown on the link field.
const _linkErrors = {'bad_link', 'own_invite'};

/// "This Invite Was Already Used": the app's error dialog, the red mark and
/// one Close, for a link someone else opened first or that expired.
Future<void> _showInviteUsedDialog(BuildContext context) => AppDialog.show(
  context: context,
  centeredTitle: true,
  // Small phones with large text: keep Close reachable.
  scrollable: true,
  header: const Center(
    key: Key('help_friend.already_claimed'),
    child: AppImage(
      path: AppImagePaths.errorIcon,
      height: 48,
      useThemeColor: false,
    ),
  ),
  title: 'help_friend_already_claimed_title'.i18n,
  body: 'help_friend_already_claimed_body'.i18n,
  primaryLabel: 'close'.i18n,
);

enum _ClaimOutcome { waiting, approved, gone }

/// What became of this screen's claim. While it is in the view it waits,
/// whatever other claims do. Once it has left, a new pairing means it was
/// approved; none means it was rejected, expired or pruned. [seen] says the
/// view reflects the claim at all: a claim whose refresh failed is missing
/// from the view it was answered with, and has not left.
_ClaimOutcome _claimOutcome(
  HelpersView view,
  String? claimId,
  Set<String> helpingAtClaim, {
  required bool seen,
}) {
  if (claimId != null && view.claims.any((c) => c.id == claimId)) {
    return _ClaimOutcome.waiting;
  }
  if (view.helping.any((p) => !helpingAtClaim.contains(p.pairingId))) {
    return _ClaimOutcome.approved;
  }
  // Without its ID, nothing says the claim is gone.
  return claimId != null && seen ? _ClaimOutcome.gone : _ClaimOutcome.waiting;
}

/// The name of the pairing this claim became, or the generic wording when it
/// cannot be told apart. The engine drops a claim when its key opens the new
/// pairing's name, so the claim must be gone and exactly one pairing new.
String _approvedName(
  HelpersState helpers,
  String? claimId,
  Set<String> helpingAtClaim,
) {
  final view = helpers.view;
  final stillPending =
      claimId == null || view.claims.any((c) => c.id == claimId);
  final added = view.helping
      .where((p) => !helpingAtClaim.contains(p.pairingId))
      .toList();
  if (stillPending || added.length != 1 || added.single.name.isEmpty) {
    return 'helping_unnamed'.i18n;
  }
  return added.single.name;
}
