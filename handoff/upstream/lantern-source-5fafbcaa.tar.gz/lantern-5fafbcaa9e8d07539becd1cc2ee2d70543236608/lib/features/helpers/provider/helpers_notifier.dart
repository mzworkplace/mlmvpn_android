import 'dart:async';
import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:lantern/core/common/app_build_info.dart';
import 'package:lantern/core/models/feature_flags.dart';
import 'package:lantern/core/services/injection_container.dart';
import 'package:lantern/core/services/local_storage_service.dart';
import 'package:lantern/core/services/logger_service.dart';
import 'package:lantern/features/helpers/helper_key_store.dart';
import 'package:lantern/features/helpers/models/helpers_view.dart';
import 'package:lantern/features/home/provider/feature_flag_notifier.dart';
import 'package:lantern/lantern/lantern_service.dart';
import 'package:lantern/lantern/lantern_service_notifier.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'helpers_notifier.g.dart';

/// Whether this build and the server let this device use helper invites.
@riverpod
bool helperInvitesAvailable(Ref ref) =>
    AppBuildInfo.enableHelperInvites &&
    ref.watch(featureFlagProvider).getBool(FeatureFlag.helperInvites);

/// Whether Manage Private Locations shows its "Personal Proxies" tab: while
/// helper invites are available, and after the flag goes off while this
/// device still has personal proxies or invites to manage, or may have them:
/// it used helper invites and no view has loaded yet. Reads only the
/// notifier's state and the used mark in local storage, never the keystore.
@riverpod
bool personalProxiesTabVisible(Ref ref) {
  if (!HelpersNotifier._buildEnabled) return false;
  if (ref.watch(helperInvitesAvailableProvider)) return true;
  final s = ref.watch(helpersProvider);
  if (!s.viewLoaded && ref.read(helpersProvider.notifier).used) return true;
  return s.view.helpers.isNotEmpty || s.view.invites.any((i) => !i.expired);
}

/// Whether the VPN tab offers "Get a personal proxy": while helper invites
/// are available and this device has no personal proxy. A device that never
/// used helper invites has none, so the keystore is never touched to decide;
/// one that did waits for a loaded view.
@riverpod
bool personalProxyBannerVisible(Ref ref) {
  if (!ref.watch(helperInvitesAvailableProvider)) return false;
  final s = ref.watch(helpersProvider);
  if (!s.viewLoaded) return !ref.read(helpersProvider.notifier).used;
  return s.view.helpers.isEmpty;
}

/// Whether a friend who claimed an invite waits on this user's approval, in
/// a build and for a server that offer helper invites. The VPN tab then gives
/// the banner's waiting variant the Pro banner's slot, and shows it to a user
/// who already has a personal proxy too: the wait is short and the invite
/// expires.
@riverpod
bool personalProxyWaiting(Ref ref) {
  if (!HelpersNotifier.buildEnabled) return false;
  if (ref.watch(helpersProvider).view.awaitingApproval == null) return false;
  return ref.watch(helperInvitesAvailableProvider);
}

/// One engine call's result: its JSON, or an error code.
class HelperResult {
  const HelperResult._(this.data, this.error);

  final Map<String, dynamic> data;
  final String? error;

  bool get ok => error == null;

  factory HelperResult.failure(String code) => HelperResult._(const {}, code);

  factory HelperResult.parse(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        final err = decoded['error'];
        if (err != null) {
          final code = err.toString();
          return HelperResult._(
            const {},
            code == 'not_initialized' ? 'unavailable' : code,
          );
        }
        return HelperResult._(decoded, null);
      }
    } catch (_) {
      // Not JSON: the core is not answering.
    }
    return const HelperResult._({}, 'unavailable');
  }
}

class HelpersState {
  const HelpersState({
    this.view = const HelpersView(),
    this.error,
    this.helpOthers = true,
    this.requestedHelpOthers,
    this.helpingApprovals = 0,
    this.keystoreReset = false,
    this.viewLoaded = false,
  });

  final HelpersView view;

  /// The last operation's error code, cleared by the next success.
  final String? error;

  /// "Help others too" (radiance peer_serve_pool; unset means on).
  final bool helpOthers;

  /// The latest "help others too" choice not yet saved, if any.
  final bool? requestedHelpOthers;

  /// What "Who you're helping" shows: the choice being saved, else the
  /// saved one.
  bool get chosenHelpOthers => requestedHelpOthers ?? helpOthers;

  /// Counts refreshes that found a new pairing this device helps. Home starts
  /// sharing when it grows.
  final int helpingApprovals;

  /// The keystore lost the old key, so the old names could not be read. It
  /// stays set until the UI calls [HelpersNotifier.acknowledgeKeystoreReset].
  final bool keystoreReset;

  /// Whether a view from the engine has been applied: until then [view] is
  /// the empty initial one, not what this device holds.
  final bool viewLoaded;

  HelpersState copyWith({
    HelpersView? view,
    String? error,
    bool clearError = false,
    bool? helpOthers,
    bool? requestedHelpOthers,
    bool clearRequestedHelpOthers = false,
    int? helpingApprovals,
    bool? keystoreReset,
    bool? viewLoaded,
  }) => HelpersState(
    view: view ?? this.view,
    error: clearError ? null : (error ?? this.error),
    helpOthers: helpOthers ?? this.helpOthers,
    requestedHelpOthers: clearRequestedHelpOthers
        ? null
        : (requestedHelpOthers ?? this.requestedHelpOthers),
    helpingApprovals: helpingApprovals ?? this.helpingApprovals,
    keystoreReset: keystoreReset ?? this.keystoreReset,
    viewLoaded: viewLoaded ?? this.viewLoaded,
  );
}

/// The app's side of helper invites. Every operation goes to lantern-core's
/// engine through [LanternService.helperCall]. Links, names and codes are
/// never logged.
@Riverpod(keepAlive: true)
class HelpersNotifier extends _$HelpersNotifier {
  /// Set once the user has used helper invites, so the keystore is never
  /// touched for anyone else.
  static const usedKey = 'helper_invites_used';

  @visibleForTesting
  static Duration pollInterval = const Duration(seconds: 30);

  /// How long a launch refresh waits for the core before trying anyway.
  @visibleForTesting
  static Duration radianceWait = const Duration(seconds: 30);

  /// Lets a test play a stealth build. Production reads the const.
  @visibleForTesting
  static bool? debugBuildEnabled;

  static bool get _buildEnabled =>
      debugBuildEnabled ?? AppBuildInfo.enableHelperInvites;

  /// Whether this build has helper invites; a stealth build does not.
  static bool get buildEnabled => _buildEnabled;

  Timer? _poll;
  Future<void>? _unlocking;

  /// Whether the engine has accepted the key. Kept apart from the view's
  /// `unlocked`, so a relock does not wipe the lists on screen.
  bool _engineUnlocked = false;

  /// Each engine request's number, so a view that was requested before the
  /// last applied one cannot overwrite it.
  int _sent = 0;
  int _applied = 0;
  String? _heldLink;

  /// The claimed invites whose approval sheet was shown or offered on this
  /// device, by invite ID. Memory only.
  final _approvalPrompted = <String>{};

  /// Records that [inviteId]'s approval was put in front of the user, so the
  /// app-wide prompt does not open it again. Returns whether it was new.
  bool markApprovalPrompted(String inviteId) => _approvalPrompted.add(inviteId);

  bool approvalPrompted(String inviteId) =>
      _approvalPrompted.contains(inviteId);

  /// HelpFriend screens waiting on their own claim. Memory only.
  int _approvalStartHolds = 0;

  /// While a HelpFriend screen waits on its claim, its success screen asks
  /// whether to keep Action Mode on, so Home does not start sharing for the
  /// approval itself. Each hold is released once. One released before its
  /// success screen asked starts nothing: the pairing stands, and sharing
  /// waits for the user to turn Action Mode on.
  void holdApprovalStart() => _approvalStartHolds++;

  void releaseApprovalStart() {
    if (_approvalStartHolds > 0) _approvalStartHolds--;
  }

  bool get approvalStartHeld => _approvalStartHolds > 0;

  /// Holds an invite link that opened the app, for HelpFriend to take, so
  /// the secret never travels in route arguments. Memory only.
  void holdLink(String link) => _heldLink = link;

  /// Returns the held link once, and forgets it.
  String? takeLink() {
    final link = _heldLink;
    _heldLink = null;
    return link;
  }

  @override
  HelpersState build() {
    ref.onDispose(() => _poll?.cancel());
    return const HelpersState();
  }

  LanternService get _svc => ref.read(lanternServiceProvider);

  LocalStorageService get _storage => sl<LocalStorageService>();

  bool get used => _storage.getBool(usedKey) ?? false;

  @visibleForTesting
  bool get polling => _poll != null;

  Future<_Answer> _send(String op, Map<String, dynamic> args) async {
    final seq = ++_sent;
    final res = await _svc.helperCall(op, args);
    return (
      res.fold((_) => HelperResult.failure('unavailable'), HelperResult.parse),
      seq,
    );
  }

  /// Calls the engine. When the engine answers `locked` (lantern-core
  /// restarted under us), it unlocks again and retries once. That is safe
  /// for every op: the engine refuses a locked call before running it.
  Future<_Answer> _call(
    String op, [
    Map<String, dynamic> args = const {},
  ]) async {
    if (!_buildEnabled) {
      return (HelperResult.failure('unavailable'), 0);
    }
    var a = await _send(op, args);
    if (a.$1.error != 'locked' || op == 'unlock' || !used) return a;
    _engineUnlocked = false;
    if (!await ensureUnlocked()) {
      return (HelperResult.failure(state.error ?? 'unavailable'), 0);
    }
    a = await _send(op, args);
    if (a.$1.error == 'locked') return (HelperResult.failure('unavailable'), 0);
    return a;
  }

  /// Applies an answer. A view replaces the view unless a later-requested
  /// view was already applied; an error is kept. A view's one-shot flags are
  /// handled either way, by [_oneShots]: the engine reports each once, so
  /// dropping one with a stale view would lose it. [refetch] asks for the
  /// config after a successful op that changed who helps this device.
  HelperResult _apply(_Answer a, {bool isView = true, bool refetch = false}) {
    final (r, seq) = a;
    if (!ref.mounted) return r;
    if (!r.ok) {
      state = state.copyWith(error: r.error);
      return r;
    }
    if (!isView) {
      state = state.copyWith(clearError: true);
      if (refetch) unawaited(_refetchConfig());
      return r;
    }
    if (seq >= _applied) {
      _applied = seq;
      final view = HelpersView.fromJson(r.data);
      state = state.copyWith(view: view, clearError: true, viewLoaded: true);
      _schedulePoll(view);
    }
    _oneShots(r.data, refetch: refetch);
    return r;
  }

  /// Acts on a successful view's one-shot flags, from any op, whether the
  /// view was applied or too old. new_helping counts an approval (Home
  /// starts sharing) and, with helpers_changed or [refetch], fetches the
  /// config at most once: the one that turns the widget on for a new
  /// volunteer, or carries or drops a helper's route.
  void _oneShots(Map<String, dynamic> data, {bool refetch = false}) {
    final newHelping = data['new_helping'] == true;
    if (newHelping) {
      state = state.copyWith(helpingApprovals: state.helpingApprovals + 1);
    }
    if (data['keystore_reset'] == true) {
      // The keystore returned a new key: the old names could not be read and
      // were set aside. Tell the user once they look.
      state = state.copyWith(keystoreReset: true);
    }
    if (refetch || newHelping || data['helpers_changed'] == true) {
      unawaited(_refetchConfig());
    }
  }

  /// Unlocks the engine with the keystore key, once.
  Future<bool> ensureUnlocked() async {
    if (!_buildEnabled) return false;
    if (_engineUnlocked) return true;
    await (_unlocking ??= _unlock().whenComplete(() => _unlocking = null));
    return _engineUnlocked;
  }

  /// Clears [HelpersState.keystoreReset] once the user has seen it.
  void acknowledgeKeystoreReset() =>
      state = state.copyWith(keystoreReset: false);

  Future<void> _unlock() async {
    await _storage.setBool(usedKey, true);
    final String key;
    try {
      key = await sl<HelperKeyStore>().stateKey();
    } catch (_) {
      appLogger.error('helper: the OS keystore is unavailable');
      if (ref.mounted) state = state.copyWith(error: 'keystore');
      return;
    }
    final r = _apply(await _call('unlock', {'key': key}));
    _engineUnlocked = r.ok && r.data['unlocked'] == true;
  }

  Future<HelperResult?> _guard() async {
    if (!_buildEnabled) return HelperResult.failure('unavailable');
    if (await ensureUnlocked()) return null;
    return HelperResult.failure(state.error ?? 'keystore');
  }

  Future<HelperResult> refresh() async {
    final locked = await _guard();
    if (locked != null) return locked;
    return _apply(await _call('refresh'));
  }

  Future<void> _refetchConfig() async {
    try {
      final res = await _svc.sendConfigRequest();
      if (res.isLeft()) {
        // The feature flags cached now are the stale ones; radiance's own
        // config poll fetches both later.
        appLogger.error('helper: refetching config failed');
        return;
      }
      if (ref.mounted) {
        await ref.read(featureFlagProvider.notifier).fetchFeatureFlags();
      }
    } catch (_) {
      appLogger.error('helper: refetching config failed');
    }
  }

  /// Refreshes only on a device that has used helper invites, in a build
  /// that has them. At launch the core may still be starting (Android), so
  /// it waits for it first; anyone else never waits.
  Future<void> refreshIfUsed() async {
    if (!_buildEnabled || !used) return;
    try {
      await _svc.waitForRadiance().timeout(radianceWait);
    } catch (_) {
      appLogger.warning('helper: the core is not ready; refreshing anyway');
    }
    if (!ref.mounted) return;
    await refresh();
  }

  Future<HelperResult> refreshView() async => _apply(await _call('view'));

  /// lantern-core says the live status of the friends this device helps
  /// changed: reads the view again, which carries it. It costs no request to
  /// lantern-cloud. Only once the engine is unlocked, so the keystore is
  /// never touched for it, and a failed read keeps the last view and error.
  Future<void> liveChanged() async {
    if (!_buildEnabled || !_engineUnlocked) return;
    final a = await _call('view');
    if (a.$1.ok) _apply(a);
  }

  /// Whether this device helps a friend through a helper-invite pairing,
  /// from the view applied so far. False on a device that never used helper
  /// invites or a build without them; null while no view has loaded.
  bool? get helpsSomeoneNow {
    if (!_buildEnabled || !used) return false;
    if (!state.viewLoaded) return null;
    return state.view.helping.isNotEmpty;
  }

  /// Loads the local view (no network) and answers [helpsSomeoneNow]. The
  /// keystore is never touched on a device that never used helper invites.
  Future<bool?> helpsSomeone() async {
    if (!_buildEnabled || !used) return false;
    if (await ensureUnlocked()) await refreshView();
    if (!ref.mounted) return null;
    return helpsSomeoneNow;
  }

  Future<HelperResult> createInvite(String name) async {
    final locked = await _guard();
    if (locked != null) return locked;
    final r = _apply(
      await _call('create_invite', {'name': name}),
      isView: false,
    );
    if (!r.ok) return r;
    // The share screen reads the new invite from the view: without it, the
    // invite (kept by the engine) shows at the next view instead.
    var v = await refreshView();
    if (!v.ok && ref.mounted) v = await refreshView();
    return v.ok ? r : v;
  }

  /// Sets the name the user gives in an invite not yet decided, as typed on
  /// the invite screen after its link was made. It stays on this device
  /// until the approval.
  Future<HelperResult> renameInvite(String inviteId, String name) async =>
      _apply(
        await _call('rename_invite', {'invite_id': inviteId, 'name': name}),
      );

  Future<HelperResult> decide(String inviteId, {required bool approve}) async {
    // The new helper's route comes with the config: fetch it now rather
    // than at the next poll.
    return _apply(
      await _call('decide', {'invite_id': inviteId, 'approve': approve}),
      refetch: approve,
    );
  }

  Future<HelperResult> forgetInvite(String inviteId) async =>
      _apply(await _call('forget_invite', {'invite_id': inviteId}));

  Future<HelperResult> claim(String link, String name) async {
    final locked = await _guard();
    if (locked != null) return locked;
    final r = _apply(
      await _call('claim', {'link': link, 'name': name}),
      isView: false,
    );
    if (!r.ok) return r;
    // The claim waits on the inviter, so poll for the answer even when the
    // view that would have started polling fails.
    final v = await refreshView();
    if (!v.ok && ref.mounted) _startPoll();
    return r;
  }

  /// After an ended pairing, the config is fetched so its route goes now.
  Future<HelperResult> endPairing(String pairingId) async => _apply(
    await _call('end_pairing', {'pairing_id': pairingId}),
    refetch: true,
  );

  /// Sets the name this device shows for one of its personal proxies, or
  /// restores the friend's own when [name] is blank. It stays on this device.
  Future<HelperResult> renameHelper(String pairingId, String name) async =>
      _apply(
        await _call('rename_helper', {'pairing_id': pairingId, 'name': name}),
      );

  /// The engine erases the names before it contacts lantern-cloud, so when
  /// the network step fails the local view (already without them) is shown,
  /// with the original error kept. When that view fails too, the names are
  /// erased from the one on screen.
  Future<HelperResult> endAllHelpers() async {
    final r = _apply(await _call('end_all_helpers'), refetch: true);
    if (r.ok || !ref.mounted) return r;
    final v = await refreshView();
    if (!ref.mounted) return r;
    if (!v.ok) _replaceView(_withoutHelperNames(state.view));
    state = state.copyWith(error: r.error);
    return r;
  }

  /// Replaces the view on screen as a newly requested view would, so that no
  /// view requested earlier overwrites it. Their new_helping still counts in
  /// [_apply].
  void _replaceView(HelpersView view) {
    _applied = ++_sent;
    state = state.copyWith(view: view);
  }

  /// [view] without the names the engine erases in "remove all helpers".
  static HelpersView _withoutHelperNames(HelpersView view) => HelpersView(
    unlocked: view.unlocked,
    myName: view.myName,
    invites: [
      for (final i in view.invites)
        HelperInviteView(
          id: i.id,
          state: i.state,
          link: i.link,
          expiresUnix: i.expiresUnix,
          code: i.code,
          inviterName: i.inviterName,
        ),
    ],
    claims: view.claims,
    helpers: [
      for (final h in view.helpers)
        HelperPairingView(
          pairingId: h.pairingId,
          online: h.online,
          sinceUnix: h.sinceUnix,
          hasPairingKey: h.hasPairingKey,
        ),
    ],
    helping: view.helping,
    activity: view.activity,
  );

  /// Counts completed writes of "help others too", so a read that started
  /// before one cannot overwrite it.
  int _helpOthersWrites = 0;

  Future<void> loadHelpOthers() async {
    final writes = _helpOthersWrites;
    final res = await _svc.getSettings();
    if (!ref.mounted || writes != _helpOthersWrites) return;
    res.fold((_) {}, (s) {
      final v = s['peer_serve_pool'];
      state = state.copyWith(helpOthers: v is bool ? v : true);
    });
  }

  /// Numbers each choice from "Who you're helping", so only the latest one's
  /// completion clears [HelpersState.requestedHelpOthers].
  int _helpOthersRequests = 0;

  /// A choice from "Who you're helping". It is compared with the latest
  /// choice not yet saved, else the saved value, and written only when it
  /// differs. Kept here rather than in the sheet, which can be closed and
  /// reopened while a write is in flight.
  Future<void> chooseHelpOthers(bool value) {
    if (value == state.chosenHelpOthers) return Future.value();
    state = state.copyWith(requestedHelpOthers: value);
    final request = ++_helpOthersRequests;
    return setHelpOthers(value).whenComplete(() {
      if (!ref.mounted || request != _helpOthersRequests) return;
      state = state.copyWith(clearRequestedHelpOthers: true);
    });
  }

  /// Writes of "help others too" run one at a time, in order, so an older
  /// response can never land after a newer one.
  Future<void> _helpOthersChain = Future.value();

  Future<void> setHelpOthers(bool value) {
    final next = _helpOthersChain.then((_) => _writeHelpOthers(value));
    _helpOthersChain = next.catchError((Object _) {});
    return next;
  }

  Future<void> _writeHelpOthers(bool value) async {
    final res = await _svc.patchSettings({'peer_serve_pool': value});
    if (!ref.mounted) return;
    res.fold(
      (f) =>
          appLogger.error('helper: setting help-others-too failed: ${f.error}'),
      (_) {
        _helpOthersWrites++;
        state = state.copyWith(helpOthers: value);
      },
    );
  }

  void _schedulePoll(HelpersView view) {
    if (!view.needsPolling) {
      _poll?.cancel();
      _poll = null;
      return;
    }
    _startPoll();
  }

  void _startPoll() {
    _poll ??= Timer.periodic(pollInterval, (_) {
      if (WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) {
        return;
      }
      unawaited(refresh());
    });
  }
}

typedef _Answer = (HelperResult, int);
