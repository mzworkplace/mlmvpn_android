import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:lantern/core/widgets/info_row.dart';
import 'package:lantern/core/widgets/setting_tile.dart';
import 'package:lantern/features/helpers/personal_proxy_banner.dart';
import 'package:lantern/features/helpers/provider/helpers_notifier.dart';
import 'package:lantern/features/home/provider/radiance_settings_providers.dart';
import 'package:lantern/features/split_tunneling/provider/split_tunnel_notifier.dart';
import 'package:lantern/features/vpn/location_setting.dart';
import 'package:lantern/features/vpn/pinned_server_warning.dart';
import 'package:lantern/features/vpn/provider/server_location_notifier.dart';
import 'package:lantern/features/vpn/vpn_status.dart';
import 'package:lantern/features/vpn/vpn_switch.dart';

import '../../core/common/common.dart';

/// VPN tab body — the connect toggle, data usage, location, routing and
/// split-tunnel rows. Originally the body of the Home screen; lifted out
/// when Home was refactored into a two-tab shell (VPN + Unbounded). No
/// Scaffold or AppBar — the shell provides that chrome.
class VpnTab extends ConsumerWidget {
  const VpnTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isUserPro = ref.watch(isUserProProvider);
    final serverLocation = ref.watch(serverLocationProvider);
    final serverType = serverLocation.serverType.toServerLocationType;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: defaultSize),
        // Preserve the spaced layout when it fits while allowing the body to
        // grow and scroll when the window leaves less vertical room.
        child: LayoutBuilder(
          builder: (context, constraints) => SingleChildScrollView(
            primary: false,
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  // A friend waiting on approval takes the slot: the wait is
                  // short and the invite expires. Otherwise it is the Pro
                  // upsell's. "Get a Personal Proxy" has no card here: its
                  // entry points are the Private Locations list and VPN
                  // Settings.
                  if (ref.watch(personalProxyWaitingProvider))
                    const PersonalProxyBanner()
                  else if (proBannerShows(ref))
                    const ProBanner()
                  else
                    // Keeps the slot, so the switch stays centred between it
                    // and the cards rather than rising to the top.
                    const SizedBox.shrink(),
                  const VPNSwitch(),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      if (!isUserPro) ...{
                        if (serverType == ServerLocationType.privateServer)
                          InfoRow(text: 'private_server_usage_message'.i18n)
                        else if (!isSmallScreen(context))
                          const DataUsage(),
                      },
                      const PinnedServerWarning(),
                      const SizedBox(height: 8),
                      _SettingCard(),
                      const SizedBox(height: defaultSize),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SettingCard extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final routingMode = ref.watch(
      radianceSettingsProvider.select((s) => s.routingMode),
    );
    final isUserPro = ref.watch(isUserProProvider);
    final serverType = ref
        .watch(serverLocationProvider)
        .serverType
        .toServerLocationType;

    // Small screens only (engineering#3046); regular screens show the
    // standalone DataUsage card in VpnTab instead. Same visibility rules:
    // free users, not private servers.
    final smallScreen = isSmallScreen(context);
    final showDataUsage =
        smallScreen &&
        !isUserPro &&
        serverType != ServerLocationType.privateServer;
    final showSplitTunneling = PlatformUtils.supportsSplitTunneling;
    final splitTunnel = showSplitTunneling
        ? ref.watch(splitTunnelProvider)
        : null;

    // Small screens drop the > chevrons; rows stay tappable via onTap.
    final chevronActions = smallScreen
        ? const <Widget>[]
        : const <Widget>[AppImage(path: AppImagePaths.arrowForward)];
    final routingTile = SettingTile(
      label: 'routing_mode'.i18n,
      icon: AppImagePaths.route,
      value: routingMode.label(),
      actions: chevronActions,
      onTap: () => appRouter.push(const SmartRouting()),
    );
    final splitTunnelingTile = SettingTile(
      // Tapped by the split-tunneling smoke harness.
      tileKey: const Key('home.split_tunneling_setting'),
      label: 'split_tunneling'.i18n,
      icon: AppImagePaths.callSpilt,
      value: splitTunnelLabel(splitTunnel),
      actions: chevronActions,
      onTap: () => appRouter.push(const SplitTunneling()),
    );

    return Container(
      decoration: const BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: AppColors.shadowColor,
            blurRadius: 32,
            offset: Offset(0, 4),
            spreadRadius: 0,
          ),
        ],
      ),
      child: Card(
        elevation: 0,
        margin: EdgeInsets.zero,
        child: Column(
          children: [
            // Brings its own trailing divider, shown only when visible.
            if (showDataUsage) const DataUsage(insideCard: true),
            const VpnStatus(),
            const DividerSpace(),
            const LocationSetting(),
            const DividerSpace(),
            // Small screens: Routing Mode | Split Tunneling share one row;
            // otherwise stacked full-width rows.
            if (showSplitTunneling && smallScreen)
              Row(
                children: [
                  Expanded(child: routingTile),
                  SizedBox(
                    height: 40,
                    child: VerticalDivider(
                      width: 1,
                      color: Theme.of(context).dividerTheme.color,
                    ),
                  ),
                  Expanded(child: splitTunnelingTile),
                ],
              )
            else ...[
              routingTile,
              if (showSplitTunneling) const DividerSpace(),
              if (showSplitTunneling) splitTunnelingTile,
            ],
          ],
        ),
      ),
    );
  }
}
