/*
 * Copyright (c) 2020, Psiphon Inc.
 * All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#import <Foundation/Foundation.h>
#import <Psi/Psi.h>

NS_ASSUME_NONNULL_BEGIN

@interface IPv6Synthesizer : NSObject

/// Synthesize an IPv6 address from an IPv4 address on a DNS64/NAT64 network
+ (NSString *)IPv4ToIPv6:(NSString *)IPv4Addr;

@end

NS_ASSUME_NONNULL_END
